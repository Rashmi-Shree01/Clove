$('[data-toggle="popover"]').popover();

//customer funnel chart
function customerFunnel(idToUse,customerFunnelData) {
                
	const funnelData = [];
	var obj = {};

	$.each(customerFunnelData,  function(index, detail){
		obj = {label: detail['label'], value: parseInt(detail['value'])};
		funnelData.push(obj);
	})
	createFunnelChart(idToUse, funnelData);
	function createFunnelChart(idToUse, data) {
		const options = {
			chart: {
				width: 350,
				height: 300,
				animate: 200
			},
			block: {
				dynamicHeight: true,
				minHeight: 15,
				fill: {
					type: 'gradient',
					scale: ['#9087c0','#96d1f3','#f489a7','#c5e5d6']
				}
			},
			label: {
				fontFamily: 'Open sans',
				fontSize: 12
			},
			tooltip: {
				enabled: false
			}
		};
	
		const chart = new D3Funnel('#'+idToUse);
		chart.draw(data, options);
	};
};

//retention table
function customerRetention(idToUse,retentionTable) {
	var dates = [];
	var userCounts = [];
	var days = []

	$.each(retentionTable,function(index, detail){
		userCounts.push(detail['custCount']);
		dates.push(index);
		var day = [detail['retention']['day0'],detail['retention']['day1'],detail['retention']['day2'],detail['retention']['day3'],detail['retention']['day4'],detail['retention']['day5'],detail['retention']['day6']];
		days.push(day);
	});

	$.each(days,function(index,day){
		$('#'+idToUse).find('tbody:last').append('<tr id="retention-'+index+'"><td>'+dates[index]+'</td><td>'+userCounts[index]+'</td>');
		$.each(day,function(i,r){
			if(i<= (day.length-index -1)){
				$("#retention-"+index).append('<td>'+r+"%</td>")
			}
		});
		$('#'+idToUse).find('tbody:last').append('</tr>');
	});   
};

//customer details table
function customerDetails(customerTable) {
	var tableData = [];
	var columns = [];

	$.each(customerTable,function(index, detail){	
		var data = {
						"Customer" : detail['customer'],
						"City" : detail['city'],
						"LTV" : "$"+detail['ltv'],
						"Total Orders" : detail['totalOrders'],
						"Avg Qty/Order" : detail['avgQtyPerOrder'],
						"Purchase Frequency" : detail['purchaseFrequency'],
						"Last Ordered Date" : detail['lastOrderedDate'],
						"Preferred Channel" : detail['channel'],
						"Device" : detail['device']
		};
		tableData.push(data);
	});
	columns = [
				{data : "Customer"},
				{data : "City"},
				{data : "LTV"},
				{data : "Total Orders"},
				{data : "Avg Qty/Order"},
				{data : "Purchase Frequency"},
				{data : "Last Ordered Date"},
				{data : "Preferred Channel"},
				{data : "Device"}
	];
	
	createDataTable('customerDetailsTable',tableData,columns);
};

orderTable = [
	{
		"date": "12-Jul-19",
		"orderNum": "G3-44748",
		"amt": "124",
		"status": "Complete"
	},
	{
		"date": "13-Jul-19",
		"orderNum": "G3-45746",
		"amt": "120",
		"status": "Complete"
	},
	{
		"date": "14-Jul-19",
		"orderNum": "G4-44888",
		"amt": "130",
		"status": "Complete"
	},
	{
		"date": "15-Jul-19",
		"orderNum": "G3-44587",
		"amt": "124",
		"status": "Complete"
	},
	{
		"date": "15-Jul-19",
		"orderNum": "G4-43588",
		"amt": "120",
		"status": "Complete"
	}
]

function orderHistoryTable(orderTable) {
	var tableData = [];
	var columns = [];

	$.each(orderTable,function(index, detail){	
		var data = {
						"Date" : detail['date'],
						"Order Number" : detail['orderNum'],
						"Amount" : "$"+detail['amt'],
						"Status" : detail['status']
		};
		tableData.push(data);
	});
	columns = [
				{data : "Date"},
				{data : "Order Number"},
				{data : "Amount"},
				{data : "Status"}
	];
	
	createDataTable('orderHistory',tableData,columns);
};

orderHistoryTable(orderTable);

productPurchaseTable = [
	{
		"product": "Tennis Racket",
		"qty": "2",
		"amt": "524"
	},
	{
		"product": "Baseball Bat",
		"qty": "5",
		"amt": "124"
	},
	{
		"product": "Cap",
		"qty": "2",
		"amt": "80"
	},
	{
		"product": "Shoes",
		"qty": "3",
		"amt": "110"
	},
	{
		"product": "Socks",
		"qty": "10",
		"amt": "100"
	}
]

function purchaseTable(productPurchaseTable) {
	var tableData = [];
	var columns = [];

	$.each(productPurchaseTable,function(index, detail){	
		var data = {
						"Product Name" : detail['product'],
						"Quantity" : detail['qty'],
						"Amount" : "$"+detail['amt']
		};
		tableData.push(data);
	});
	columns = [
				{data : "Product Name"},
				{data : "Quantity"},
				{data : "Amount"}
	];
	
	createDataTable('productPurchase',tableData,columns);
};

purchaseTable(productPurchaseTable);

visitsTable = [
	{
		"date": "12-Jul-19",
		"landingPage": "www.bestbuys.com",
		"refPage": "www.google.com",
		"campaignName": "email_20%",
		"time": "2min 20sec",
		"pagesVisited":"5"
	},
	{
		"date": "13-Jul-19",
		"landingPage": "www.bestbuys.com/shoes",
		"refPage": "www.google.com",
		"campaignName": "best shoes",
		"time": "1min 30sec",
		"pagesVisited":"2"
	},
	{
		"date": "14-Jul-19",
		"landingPage": "www.bestbuys.com/sports/bat",
		"refPage": "www.google.com",
		"campaignName": "all bats",
		"time": "3min 10sec",
		"pagesVisited":"1"
	},
	{
		"date": "15-Jul-19",
		"landingPage": "www.bestbuys.com/sports/tennis",
		"refPage": "www.google.com",
		"campaignName": "tennis_sports",
		"time": "2min 10sec",
		"pagesVisited":"3"
	},
	{
		"date": "16-Jul-19",
		"landingPage": "www.bestbuys.com/apparels",
		"refPage": "www.google.com",
		"campaignName": "apparels everyday",
		"time": "4min 10sec",
		"pagesVisited":"4"
	}
]

function visitRelatedTable(visitsTable) {
	var tableData = [];
	var columns = [];

	$.each(visitsTable,function(index, detail){	
		var data = {
						"Date" : detail['date'],
						"Landing Page" : detail['landingPage'],
						"Referrer Page" : detail['refPage'],
						"Campaign Name" : detail['campaignName'],
						"Time Spent" : detail['time'],
						"Pages Visited" : detail['pagesVisited']
		};
		tableData.push(data);
	});
	columns = [
				{data : "Date"},
				{data : "Landing Page"},
				{data : "Referrer Page"},
				{data : "Campaign Name"},
				{data : "Time Spent"},
				{data : "Pages Visited"}
	];
	
	createDataTable('visitsTableData',tableData,columns);
};

visitRelatedTable(visitsTable);

//table alignment
$('td').filter(function() {
	return this.innerHTML.match(/^[0-9\%\$\s\-\.,]+$/);
}).css('text-align','right');

$(document).ready( function() {
    


    
    

    
    
   
    

    

    
});