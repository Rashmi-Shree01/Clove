$(document).ready(function(){
    
    var yesterdayLabels = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
    var thisWeekLabels = ['Sunday', 'Monday', 'Tuesday'];
    var lastWeekLabels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var thisMonthLabels = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26];
    var lastMonthLabels = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
    var lastSixMonthLabels = ["Mar", "Apr", "May", "June", "July", "Aug"];
    var thisYearLabels = [ "Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct" ];

    paymentsThisMonthChanges();
    tableAlignment();
    $('.time-range').change(function() {
        var selectedRange = $(this).val();
        // alert(selectedRange);
        switch(selectedRange) {
            case 'Yesterday' :
                paymentsYesterdayChanges();
                tableAlignment();
                break;
            case 'This Week'    :
                paymentsThisWeekChanges();
                tableAlignment();
                break;
            case 'Last week'    :
                //paymentsLastWeekChanges();
                break;
            case 'This Month'   :
                paymentsThisMonthChanges();
                tableAlignment();
                break;
            case 'Last month'   :
                //paymentsLastMonthChanges();
                break;
            case 'Last 6 month' :
                //paymentsLastSixMonthChanges();
                break;
            case 'Year'    :
                paymentsYearChanges();
                tableAlignment();
                break;
            default             :
                paymentsThisMonthChanges();
                tableAlignment();
                break;
        }
    });

    //payments yesterday changes
    function paymentsYesterdayChanges() {
        //top row
        //add data in text()
        $('#totalRevenuePayments').text('$278,689');
        $('#totalRevenueTrend').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalTransactionsPayments').text('2,500');
        $('#totalTransactionsTrend').text('0.3%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#successRatePayments').text('84.80%');
        $('#successRateTrend').text('0.20%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#effectiveRatePayments').text('3.50%');
        $('#effectiveRateTrend').text('0.20%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //fees by payment doughnut
        //change feesLabels and feesData for timeline
        var feesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var feesData = [30, 54, 77, 18];
        doughnutCharts('feesChart', feesLabels, feesData);

        //declines doughnut
        //change declinesLabels and declinesData for timeline
        var declinesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var declinesData = [2345, 1234, 2132, 1111];
        doughnutCharts('declinesPaymentChart', declinesLabels, declinesData);

        //decline trend - stacked bar
        //change labels, dataSetOne and dataSetTwo for timeline
        var labels = [ "Paypal", "Stripe", "Authorize.net" ];
        var dataSetOne = {
            label: "Success",
            data: [90, 70, 80],
            backgroundColor: "rgb(144,135,192)",
        }

        var dataSetTwo = {
            label: "Failure",
            data: [10, 30, 20],
            backgroundColor: "rgb(150,209,243)",
        }
        
        var buttonTrend = $("#currentTrendChart").hasClass('btn btn-toggle');
        var buttonBar = $("#currentBarChart").hasClass('btn btn-toggle');
        if(buttonTrend) {
            $("#currentBarChart").removeClass('btn btn-light');
            $("#currentBarChart").addClass('btn btn-toggle');
            $("#currentTrendChart").removeClass('btn btn-toggle');
            $("#currentTrendChart").addClass('btn btn-light'); 
            $(".declineRateTrendContainer").hide();
            $(".declineRateBarContainer").show();
        }
        chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);

        //decline trends - trend chart
        //change totalDecline, declineOne, declineTwo and declineThree for timeline
        var totalDecline = {
            label : "Total Decline",
            data : [ 65, 57, 35, 34, 89, 68, 35, 87, 68, 43 ],
            fill : true,
            borderDash: [10,5],
            borderColor : 'rgba(0,0,0,0.09)',
            backgroundColor : 'rgba(0,0,0,0.07)',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineOne = {
            label : "Paypal",
            data : [ 20, 17, 25, 10, 20, 10, 10, 25, 30, 10 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(99,194,242)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineTwo = {
            label : "Stripe",
            data : [ 15, 10, 20, 14, 39, 30, 10, 35, 18, 13 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(170,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineThree = {
            label : "Authorize.net",
            data : [ 25, 30, 15, 10, 30, 28, 15, 27, 20, 10 ],
            fill : false,
            tension : 0.2,
            borderColor : 'rgb(217,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var dataSet = [ totalDecline, declineOne, declineTwo, declineThree ]
        declineTrends('declineRateTrend', thisYearLabels, dataSet);

        //revenue table
        //change revenueData for timeline
        var revenueData = [ 
            {
                "Payment Channel"    : "PayPal",
                "Total Transactions" : "1,400",
                "Success Rate"       : "90%",
                "Total Revenue"      : "$111,476",
                "Declines"           : "6",
                "Refunds"            : "$111",   
                "Chargebacks"        : "$111",
                "Fees"               : "$1,115",
                "Effective Rate"     : "3.5%"
            },
            {
                "Payment Channel"    : "Stripe",
                "Total Transactions" : "900",
                "Success Rate"       : "80%",
                "Total Revenue"      : "$83,607",
                "Declines"           : "4",
                "Refunds"            : "$920",
                "Chargebacks"        : "$167",
                "Fees"               : "$836",
                "Effective Rate"     : "2.1%"
            },
            {
                "Payment Channel"    : "Authorize.net",
                "Total Transactions" : "200",
                "Success Rate"       : "70%",
                "Total Revenue"      : "$83,607",
                "Declines"           : "2",
                "Refunds"            : "$836",
                "Chargebacks"        : "$752",
                "Fees"               : "$836",
                "Effective Rate"     : "2.3%"
            },
            {
                "Payment Channel"    : "Amazon Payments",
                "Total Transactions" : "100",
                "Success Rate"       : "65%",
                "Total Revenue"      : "$75,606",
                "Declines"           : "1",
                "Refunds"            : "$750",
                "Chargebacks"        : "$250",
                "Fees"               : "$700",
                "Effective Rate"     : "2.5%"
            } 
        ]
        tableForRevenue(revenueData);

        //toggling between bar chart and trend
        $("#currentTrendChart").click(function(){
            var buttonClass = $("#currentTrendChart").hasClass('btn btn-light');
            declineTrends('declineRateTrend', thisYearLabels, dataSet);
            if(buttonClass) {
                $("#currentTrendChart").removeClass('btn btn-light');
                $("#currentTrendChart").addClass('btn btn-toggle');
                $("#currentBarChart").removeClass('btn btn-toggle');
                $("#currentBarChart").addClass('btn btn-light');
                $(".declineRateBarContainer").hide();
                $(".declineRateTrendContainer").show();
                declineTrends('declineRateTrend', thisYearLabels, dataSet);
            } 
        });

        $("#currentBarChart").click(function(){
            var buttonClass = $("#currentBarChart").hasClass('btn btn-light');
            chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            if(buttonClass) {
                $("#currentBarChart").removeClass('btn btn-light');
                $("#currentBarChart").addClass('btn btn-toggle');
                $("#currentTrendChart").removeClass('btn btn-toggle');
                $("#currentTrendChart").addClass('btn btn-light');  
                $(".declineRateTrendContainer").hide();
                $(".declineRateBarContainer").show();
                chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            } 
        });
    }

    //payments this week changes
    function paymentsThisWeekChanges() {
        //top row
        //add data in text()
        $('#totalRevenuePayments').text('$836,067');
        $('#totalRevenueTrend').text('2.4%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#totalTransactionsPayments').text('10,000');
        $('#totalTransactionsTrend').text('0.5%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#successRatePayments').text('84.80%');
        $('#successRateTrend').text('0.40%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#effectiveRatePayments').text('3.70%');
        $('#effectiveRateTrend').text('0.40%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //fees by payment doughnut
        //change feesLabels and feesData for timeline
        var feesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var feesData = [30, 54, 77, 18];
        doughnutCharts('feesChart', feesLabels, feesData);

        //declines doughnut
        //change declinesLabels and declinesData for timeline
        var declinesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var declinesData = [2345, 1234, 2132, 1111];
        doughnutCharts('declinesPaymentChart', declinesLabels, declinesData);

        //decline trend - stacked bar
        //change labels, dataSetOne and dataSetTwo for timeline
        var labels = [ "Paypal", "Stripe", "Authorize.net" ];
        var dataSetOne = {
            label: "Success",
            data: [90, 70, 80],
            backgroundColor: "rgb(144,135,192)",
        }

        var dataSetTwo = {
            label: "Failure",
            data: [10, 30, 20],
            backgroundColor: "rgb(150,209,243)",
        }
        
        var buttonTrend = $("#currentTrendChart").hasClass('btn btn-toggle');
        var buttonBar = $("#currentBarChart").hasClass('btn btn-toggle');
        if(buttonTrend) {
            $("#currentBarChart").removeClass('btn btn-light');
            $("#currentBarChart").addClass('btn btn-toggle');
            $("#currentTrendChart").removeClass('btn btn-toggle');
            $("#currentTrendChart").addClass('btn btn-light'); 
            $(".declineRateTrendContainer").hide();
            $(".declineRateBarContainer").show();
        }
        chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);

        //decline trends - trend chart
        //change totalDecline, declineOne, declineTwo and declineThree for timeline
        var totalDecline = {
            label : "Total Decline",
            data : [ 65, 57, 35, 34, 89, 68, 35, 87, 68, 43 ],
            fill : true,
            borderDash: [10,5],
            borderColor : 'rgba(0,0,0,0.09)',
            backgroundColor : 'rgba(0,0,0,0.07)',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineOne = {
            label : "Paypal",
            data : [ 20, 17, 25, 10, 20, 10, 10, 25, 30, 10 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(99,194,242)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineTwo = {
            label : "Stripe",
            data : [ 15, 10, 20, 14, 39, 30, 10, 35, 18, 13 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(170,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineThree = {
            label : "Authorize.net",
            data : [ 25, 30, 15, 10, 30, 28, 15, 27, 20, 10 ],
            fill : false,
            tension : 0.2,
            borderColor : 'rgb(217,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var dataSet = [ totalDecline, declineOne, declineTwo, declineThree ]
        declineTrends('declineRateTrend', thisYearLabels, dataSet);

        //revenue table
        //change revenueData for timeline
        var revenueData = [ 
            {
                "Payment Channel"    : "PayPal",
                "Total Transactions" : "5,600",
                "Success Rate"       : "90%",
                "Total Revenue"      : "$278,689",
                "Declines"           : "22",
                "Refunds"            : "$134",   
                "Chargebacks"        : "$156",
                "Fees"               : "$2,787",
                "Effective Rate"     : "3.1%"
            },
            {
                "Payment Channel"    : "Stripe",
                "Total Transactions" : "3,600",
                "Success Rate"       : "80%",
                "Total Revenue"      : "$209,017",
                "Declines"           : "14",
                "Refunds"            : "$1,104",
                "Chargebacks"        : "$234",
                "Fees"               : "$2,090",
                "Effective Rate"     : "2.5%"
            },
            {
                "Payment Channel"    : "Authorize.net",
                "Total Transactions" : "800",
                "Success Rate"       : "70%",
                "Total Revenue"      : "$209,017",
                "Declines"           : "13",
                "Refunds"            : "$1,003",
                "Chargebacks"        : "$1,053",
                "Fees"               : "$2,090",
                "Effective Rate"     : "2.3%"
            },
            {
                "Payment Channel"    : "Amazon Payments",
                "Total Transactions" : "1,500",
                "Success Rate"       : "75%",
                "Total Revenue"      : "$102,606",
                "Declines"           : "10",
                "Refunds"            : "$1,000",
                "Chargebacks"        : "$2,000",
                "Fees"               : "$1,050",
                "Effective Rate"     : "2.7%"
            }
             
        ]
        tableForRevenue(revenueData);

        //toggling between bar chart and trend
        $("#currentTrendChart").click(function(){
            var buttonClass = $("#currentTrendChart").hasClass('btn btn-light');
            declineTrends('declineRateTrend', thisYearLabels, dataSet);
            if(buttonClass) {                $("#currentTrendChart").removeClass('btn btn-light');
                $("#currentTrendChart").addClass('btn btn-toggle');
                $("#currentBarChart").removeClass('btn btn-toggle');
                $("#currentBarChart").addClass('btn btn-light');
                $(".declineRateBarContainer").hide();
                $(".declineRateTrendContainer").show();
                declineTrends('declineRateTrend', thisYearLabels, dataSet);
            } 
        });

        $("#currentBarChart").click(function(){
            var buttonClass = $("#currentBarChart").hasClass('btn btn-light');
            chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            if(buttonClass) {
                $("#currentBarChart").removeClass('btn btn-light');
                $("#currentBarChart").addClass('btn btn-toggle');
                $("#currentTrendChart").removeClass('btn btn-toggle');
                $("#currentTrendChart").addClass('btn btn-light');  
                $(".declineRateTrendContainer").hide();
                $(".declineRateBarContainer").show();
                chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            } 
        });
    }

    //payments last week changes
    function paymentsLastWeekChanges() {
        //top row
        //add data in text()
        $('#totalRevenuePayments').text('');
        $('#totalRevenueTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalTransactionsPayments').text('');
        $('#totalTransactionsTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#successRatePayments').text('');
        $('#successRateTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#effectiveRatePayments').text('');
        $('#effectiveRateTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //fees by payment doughnut
        //change feesLabels and feesData for timeline
        var feesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var feesData = [30, 54, 77, 18];
        doughnutCharts('feesChart', feesLabels, feesData);

        //declines doughnut
        //change declinesLabels and declinesData for timeline
        var declinesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var declinesData = [2345, 1234, 2132, 1111];
        doughnutCharts('declinesPaymentChart', declinesLabels, declinesData);

        //decline trend - stacked bar
        //change labels, dataSetOne and dataSetTwo for timeline
        var labels = [ "Paypal", "Stripe", "Authorize.net" ];
        var dataSetOne = {
            label: "Success",
            data: [90, 70, 80],
            backgroundColor: "rgb(144,135,192)",
        }

        var dataSetTwo = {
            label: "Failure",
            data: [10, 30, 20],
            backgroundColor: "rgb(150,209,243)",
        }
        
        var buttonTrend = $("#currentTrendChart").hasClass('btn btn-toggle');
        var buttonBar = $("#currentBarChart").hasClass('btn btn-toggle');
        if(buttonTrend) {
            $("#currentBarChart").removeClass('btn btn-light');
            $("#currentBarChart").addClass('btn btn-toggle');
            $("#currentTrendChart").removeClass('btn btn-toggle');
            $("#currentTrendChart").addClass('btn btn-light'); 
            $(".declineRateTrendContainer").hide();
            $(".declineRateBarContainer").show();
        }
        chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);

        //decline trends - trend chart
        //change totalDecline, declineOne, declineTwo and declineThree for timeline
        var totalDecline = {
            label : "Total Decline",
            data : [ 65, 57, 35, 65, 57, 35, 85 ],
            fill : true,
            borderDash: [10,5],
            borderColor : 'rgba(0,0,0,0.09)',
            backgroundColor : 'rgba(0,0,0,0.07)',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineOne = {
            label : "Paypal",
            data : [ 20, 17, 25, 20, 17, 25, 45 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(99,194,242)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineTwo = {
            label : "Stripe",
            data : [ 15, 10, 20, 15, 10, 20, 41 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(170,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineThree = {
            label : "Authorize.net",
            data : [ 25, 30, 15, 25, 30, 15, 22 ],
            fill : false,
            tension : 0.2,
            borderColor : 'rgb(217,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var dataSet = [ totalDecline, declineOne, declineTwo, declineThree ]
        declineTrends('declineRateTrend', lastWeekLabels, dataSet);

        //revenue table
        //change revenueData for timeline
        var revenueData = [ 
            {
                "Payment Channel"    : "PayPal",
                "Total Transactions" : "5000",
                "Success Rate"       : "90%",
                "Total Revenue"      : "$12,000",
                "Declines"           : "10",
                "Refunds"            : "$100",   
                "Chargebacks"        : "$890",
                "Fees"               : "$150",
                "Effective Rate"     : "11.2%"
            },
            {
                "Payment Channel"    : "Stripe",
                "Total Transactions" : "4000",
                "Success Rate"       : "80%",
                "Total Revenue"      : "$10,000",
                "Declines"           : "20",
                "Refunds"            : "$110",
                "Chargebacks"        : "$790",
                "Fees"               : "$250",
                "Effective Rate"     : "5.2%"
            },
            {
                "Payment Channel"    : "Authorize.net",
                "Total Transactions" : "3000",
                "Success Rate"       : "70%",
                "Total Revenue"      : "$9,000",
                "Declines"           : "30",
                "Refunds"            : "$130",
                "Chargebacks"        : "$690",
                "Fees"               : "$350",
                "Effective Rate"     : "15.5%"
            } 
        ]
        tableForRevenue(revenueData);

        //toggling between bar chart and trend
        $("#currentTrendChart").click(function(){
            var buttonClass = $("#currentTrendChart").hasClass('btn btn-light');
            declineTrends('declineRateTrend', lastWeekLabels, dataSet);
            if(buttonClass) {
                $("#currentTrendChart").removeClass('btn btn-light');
                $("#currentTrendChart").addClass('btn btn-toggle');
                $("#currentBarChart").removeClass('btn btn-toggle');
                $("#currentBarChart").addClass('btn btn-light');
                $(".declineRateBarContainer").hide();
                $(".declineRateTrendContainer").show();
                declineTrends('declineRateTrend', lastWeekLabels, dataSet);
            } 
        });

        $("#currentBarChart").click(function(){
            var buttonClass = $("#currentBarChart").hasClass('btn btn-light');
            chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            if(buttonClass) {
                $("#currentBarChart").removeClass('btn btn-light');
                $("#currentBarChart").addClass('btn btn-toggle');
                $("#currentTrendChart").removeClass('btn btn-toggle');
                $("#currentTrendChart").addClass('btn btn-light');  
                $(".declineRateTrendContainer").hide();
                $(".declineRateBarContainer").show();
                chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            } 
        });
    }

    //payments this month changes
    function paymentsThisMonthChanges() {
        //top row
        //add data in text()
        $('#totalRevenuePayments').text('$5,573,780');
        $('#totalRevenueTrend').text('0.75%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#totalTransactionsPayments').text('40,000');
        $('#totalTransactionsTrend').text('0.2%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#successRatePayments').text('84.80%');
        $('#successRateTrend').text('0.20%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#effectiveRatePayments').text('3.80%');
        $('#effectiveRateTrend').text('0.20%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //fees by payment doughnut
        //change feesLabels and feesData for timeline
        var feesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var feesData = [30, 54, 77, 18];
        doughnutCharts('feesChart', feesLabels, feesData);

        //declines doughnut
        //change declinesLabels and declinesData for timeline
        var declinesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var declinesData = [2345, 1234, 2132, 1111];
        doughnutCharts('declinesPaymentChart', declinesLabels, declinesData);

        //decline trend - stacked bar
        //change labels, dataSetOne and dataSetTwo for timeline
        var labels = [ "Paypal", "Stripe", "Authorize.net" ];
        var dataSetOne = {
            label: "Success",
            data: [90, 70, 80],
            backgroundColor: "rgb(144,135,192)",
        }

        var dataSetTwo = {
            label: "Failure",
            data: [10, 30, 20],
            backgroundColor: "rgb(150,209,243)",
        }
        
        var buttonTrend = $("#currentTrendChart").hasClass('btn btn-toggle');
        var buttonBar = $("#currentBarChart").hasClass('btn btn-toggle');
        if(buttonTrend) {
            $("#currentBarChart").removeClass('btn btn-light');
            $("#currentBarChart").addClass('btn btn-toggle');
            $("#currentTrendChart").removeClass('btn btn-toggle');
            $("#currentTrendChart").addClass('btn btn-light'); 
            $(".declineRateTrendContainer").hide();
            $(".declineRateBarContainer").show();
        }
        chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);

        //decline trends - trend chart
        //change totalDecline, declineOne, declineTwo and declineThree for timeline
        var totalDecline = {
            label : "Total Decline",
            data : [ 65, 57, 35, 34, 89, 68, 35, 87, 68, 43 ],
            fill : true,
            borderDash: [10,5],
            borderColor : 'rgba(0,0,0,0.09)',
            backgroundColor : 'rgba(0,0,0,0.07)',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineOne = {
            label : "Paypal",
            data : [ 20, 17, 25, 10, 20, 10, 10, 25, 30, 10 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(99,194,242)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineTwo = {
            label : "Stripe",
            data : [ 15, 10, 20, 14, 39, 30, 10, 35, 18, 13 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(170,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineThree = {
            label : "Authorize.net",
            data : [ 25, 30, 15, 10, 30, 28, 15, 27, 20, 10 ],
            fill : false,
            tension : 0.2,
            borderColor : 'rgb(217,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var dataSet = [ totalDecline, declineOne, declineTwo, declineThree ]
        declineTrends('declineRateTrend', thisYearLabels, dataSet);

        //revenue table
        //change revenueData for timeline
        var revenueData = [ 
            {
                "Payment Channel"    : "PayPal",
                "Total Transactions" : "22,400",
                "Success Rate"       : "90%",
                "Total Revenue"      : "$1,114,756",
                "Declines"           : "90",
                "Refunds"            : "$161",   
                "Chargebacks"        : "$218",
                "Fees"               : "$11,148",
                "Effective Rate"     : "3.8%"
            },
            {
                "Payment Channel"    : "Stripe",
                "Total Transactions" : "14,400",
                "Success Rate"       : "80%",
                "Total Revenue"      : "$836,067",
                "Declines"           : "58",
                "Refunds"            : "$1,324",
                "Chargebacks"        : "$328",
                "Fees"               : "$8,361",
                "Effective Rate"     : "2.5%"
            },
            {
                "Payment Channel"    : "Authorize.net",
                "Total Transactions" : "3,200",
                "Success Rate"       : "70%",
                "Total Revenue"      : "$836,067",
                "Declines"           : "13",
                "Refunds"            : "$1,204",
                "Chargebacks"        : "$1,475",
                "Fees"               : "$8,361",
                "Effective Rate"     : "2.1%"
            },
            {
                "Payment Channel"    : "Amazon Payments",
                "Total Transactions" : "4,000",
                "Success Rate"       : "80%",
                "Total Revenue"      : "$866,606",
                "Declines"           : "95",
                "Refunds"            : "$900",
                "Chargebacks"        : "$250",
                "Fees"               : "$7,000",
                "Effective Rate"     : "2.5%"
            }
        ]
        tableForRevenue(revenueData);

        //toggling between bar chart and trend
        $("#currentTrendChart").click(function(){
            var buttonClass = $("#currentTrendChart").hasClass('btn btn-light');
            declineTrends('declineRateTrend', thisYearLabels, dataSet);
            if(buttonClass) {
                $("#currentTrendChart").removeClass('btn btn-light');
                $("#currentTrendChart").addClass('btn btn-toggle');
                $("#currentBarChart").removeClass('btn btn-toggle');
                $("#currentBarChart").addClass('btn btn-light');
                $(".declineRateBarContainer").hide();
                $(".declineRateTrendContainer").show();
                declineTrends('declineRateTrend', thisYearLabels, dataSet);
            } 
        });

        $("#currentBarChart").click(function(){
            var buttonClass = $("#currentBarChart").hasClass('btn btn-light');
            chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            if(buttonClass) {
                $("#currentBarChart").removeClass('btn btn-light');
                $("#currentBarChart").addClass('btn btn-toggle');
                $("#currentTrendChart").removeClass('btn btn-toggle');
                $("#currentTrendChart").addClass('btn btn-light');  
                $(".declineRateTrendContainer").hide();
                $(".declineRateBarContainer").show();
                chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            } 
        });
    }

    //payments last month changes
    function paymentsLastMonthChanges() {
        //top row
        //add data in text()
        $('#totalRevenuePayments').text('');
        $('#totalRevenueTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalTransactionsPayments').text('');
        $('#totalTransactionsTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#successRatePayments').text('');
        $('#successRateTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#effectiveRatePayments').text('');
        $('#effectiveRateTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //fees by payment doughnut
        //change feesLabels and feesData for timeline
        var feesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var feesData = [30, 54, 77, 18];
        doughnutCharts('feesChart', feesLabels, feesData);

        //declines doughnut
        //change declinesLabels and declinesData for timeline
        var declinesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var declinesData = [2345, 1234, 2132, 1111];
        doughnutCharts('declinesPaymentChart', declinesLabels, declinesData);

        //decline trend - stacked bar
        //change labels, dataSetOne and dataSetTwo for timeline
        var labels = [ "Paypal", "Stripe", "Authorize.net" ];
        var dataSetOne = {
            label: "Success",
            data: [90, 70, 80],
            backgroundColor: "rgb(144,135,192)",
        }

        var dataSetTwo = {
            label: "Failure",
            data: [10, 30, 20],
            backgroundColor: "rgb(150,209,243)",
        }
        
        var buttonTrend = $("#currentTrendChart").hasClass('btn btn-toggle');
        var buttonBar = $("#currentBarChart").hasClass('btn btn-toggle');
        if(buttonTrend) {
            $("#currentBarChart").removeClass('btn btn-light');
            $("#currentBarChart").addClass('btn btn-toggle');
            $("#currentTrendChart").removeClass('btn btn-toggle');
            $("#currentTrendChart").addClass('btn btn-light'); 
            $(".declineRateTrendContainer").hide();
            $(".declineRateBarContainer").show();
        }
        chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);

        //decline trends - trend chart
        //change totalDecline, declineOne, declineTwo and declineThree for timeline
        var totalDecline = {
            label : "Total Decline",
            data : [ 65, 57, 35, 65, 57, 35, 85 ],
            fill : true,
            borderDash: [10,5],
            borderColor : 'rgba(0,0,0,0.09)',
            backgroundColor : 'rgba(0,0,0,0.07)',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineOne = {
            label : "Paypal",
            data : [ 20, 17, 25, 20, 17, 25, 45 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(99,194,242)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineTwo = {
            label : "Stripe",
            data : [ 15, 10, 20, 15, 10, 20, 41 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(170,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineThree = {
            label : "Authorize.net",
            data : [ 25, 30, 15, 25, 30, 15, 22 ],
            fill : false,
            tension : 0.2,
            borderColor : 'rgb(217,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var dataSet = [ totalDecline, declineOne, declineTwo, declineThree ]
        declineTrends('declineRateTrend', lastMonthLabels, dataSet);

        //revenue table
        //change revenueData for timeline
        var revenueData = [ 
            {
                "Payment Channel"    : "PayPal",
                "Total Transactions" : "5000",
                "Success Rate"       : "90%",
                "Total Revenue"      : "$12,000",
                "Declines"           : "10",
                "Refunds"            : "$100",   
                "Chargebacks"        : "$890",
                "Fees"               : "$150",
                "Effective Rate"     : "11.2%"
            },
            {
                "Payment Channel"    : "Stripe",
                "Total Transactions" : "4000",
                "Success Rate"       : "80%",
                "Total Revenue"      : "$10,000",
                "Declines"           : "20",
                "Refunds"            : "$110",
                "Chargebacks"        : "$790",
                "Fees"               : "$250",
                "Effective Rate"     : "5.2%"
            },
            {
                "Payment Channel"    : "Authorize.net",
                "Total Transactions" : "3000",
                "Success Rate"       : "70%",
                "Total Revenue"      : "$9,000",
                "Declines"           : "30",
                "Refunds"            : "$130",
                "Chargebacks"        : "$690",
                "Fees"               : "$350",
                "Effective Rate"     : "15.5%"
            } 
        ]
        tableForRevenue(revenueData);

        //toggling between bar chart and trend
        $("#currentTrendChart").click(function(){
            var buttonClass = $("#currentTrendChart").hasClass('btn btn-light');
            declineTrends('declineRateTrend', lastMonthLabels, dataSet);
            if(buttonClass) {
                $("#currentTrendChart").removeClass('btn btn-light');
                $("#currentTrendChart").addClass('btn btn-toggle');
                $("#currentBarChart").removeClass('btn btn-toggle');
                $("#currentBarChart").addClass('btn btn-light');
                $(".declineRateBarContainer").hide();
                $(".declineRateTrendContainer").show();
                declineTrends('declineRateTrend', lastMonthLabels, dataSet);
            } 
        });

        $("#currentBarChart").click(function(){
            var buttonClass = $("#currentBarChart").hasClass('btn btn-light');
            chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            if(buttonClass) {
                $("#currentBarChart").removeClass('btn btn-light');
                $("#currentBarChart").addClass('btn btn-toggle');
                $("#currentTrendChart").removeClass('btn btn-toggle');
                $("#currentTrendChart").addClass('btn btn-light');  
                $(".declineRateTrendContainer").hide();
                $(".declineRateBarContainer").show();
                chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            } 
        });
    }

    //payments last six month changes
    function paymentsLastSixMonthChanges() {
        //top row
        //add data in text()
        $('#totalRevenuePayments').text('');
        $('#totalRevenueTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalTransactionsPayments').text('');
        $('#totalTransactionsTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#successRatePayments').text('');
        $('#successRateTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#effectiveRatePayments').text('');
        $('#effectiveRateTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //fees by payment doughnut
        //change feesLabels and feesData for timeline
        var feesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var feesData = [30, 54, 77, 18];
        doughnutCharts('feesChart', feesLabels, feesData);

        //declines doughnut
        //change declinesLabels and declinesData for timeline
        var declinesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var declinesData = [2345, 1234, 2132, 1111];
        doughnutCharts('declinesPaymentChart', declinesLabels, declinesData);

        //decline trend - stacked bar
        //change labels, dataSetOne and dataSetTwo for timeline
        var labels = [ "Paypal", "Stripe", "Authorize.net" ];
        var dataSetOne = {
            label: "Success",
            data: [90, 70, 80],
            backgroundColor: "rgb(144,135,192)",
        }

        var dataSetTwo = {
            label: "Failure",
            data: [10, 30, 20],
            backgroundColor: "rgb(150,209,243)",
        }
        
        var buttonTrend = $("#currentTrendChart").hasClass('btn btn-toggle');
        var buttonBar = $("#currentBarChart").hasClass('btn btn-toggle');
        if(buttonTrend) {
            $("#currentBarChart").removeClass('btn btn-light');
            $("#currentBarChart").addClass('btn btn-toggle');
            $("#currentTrendChart").removeClass('btn btn-toggle');
            $("#currentTrendChart").addClass('btn btn-light'); 
            $(".declineRateTrendContainer").hide();
            $(".declineRateBarContainer").show();
        }
        chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);

        //decline trends - trend chart
        //change totalDecline, declineOne, declineTwo and declineThree for timeline
        var totalDecline = {
            label : "Total Decline",
            data : [ 65, 57, 35, 34, 89, 68, 35, 87, 68, 43 ],
            fill : true,
            borderDash: [10,5],
            borderColor : 'rgba(0,0,0,0.09)',
            backgroundColor : 'rgba(0,0,0,0.07)',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineOne = {
            label : "Paypal",
            data : [ 20, 17, 25, 10, 20, 10, 10, 25, 30, 10 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(99,194,242)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineTwo = {
            label : "Stripe",
            data : [ 15, 10, 20, 14, 39, 30, 10, 35, 18, 13 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(170,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineThree = {
            label : "Authorize.net",
            data : [ 25, 30, 15, 10, 30, 28, 15, 27, 20, 10 ],
            fill : false,
            tension : 0.2,
            borderColor : 'rgb(217,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var dataSet = [ totalDecline, declineOne, declineTwo, declineThree ]
        declineTrends('declineRateTrend', thisYearLabels, dataSet);

        //revenue table
        //change revenueData for timeline
        var revenueData = [ 
            {
                "Payment Channel"    : "PayPal",
                "Total Transactions" : "5000",
                "Success Rate"       : "90%",
                "Total Revenue"      : "$12,000",
                "Declines"           : "10",
                "Refunds"            : "$100",   
                "Chargebacks"        : "$890",
                "Fees"               : "$150",
                "Effective Rate"     : "11.2%"
            },
            {
                "Payment Channel"    : "Stripe",
                "Total Transactions" : "4000",
                "Success Rate"       : "80%",
                "Total Revenue"      : "$10,000",
                "Declines"           : "20",
                "Refunds"            : "$110",
                "Chargebacks"        : "$790",
                "Fees"               : "$250",
                "Effective Rate"     : "5.2%"
            },
            {
                "Payment Channel"    : "Authorize.net",
                "Total Transactions" : "3000",
                "Success Rate"       : "70%",
                "Total Revenue"      : "$9,000",
                "Declines"           : "30",
                "Refunds"            : "$130",
                "Chargebacks"        : "$690",
                "Fees"               : "$350",
                "Effective Rate"     : "15.5%"
            } 
        ]
        tableForRevenue(revenueData);

        //toggling between bar chart and trend
        $("#currentTrendChart").click(function(){
            var buttonClass = $("#currentTrendChart").hasClass('btn btn-light');
            declineTrends('declineRateTrend', lastSixMonthLabels, dataSet);
            if(buttonClass) {
                $("#currentTrendChart").removeClass('btn btn-light');
                $("#currentTrendChart").addClass('btn btn-toggle');
                $("#currentBarChart").removeClass('btn btn-toggle');
                $("#currentBarChart").addClass('btn btn-light');
                $(".declineRateBarContainer").hide();
                $(".declineRateTrendContainer").show();
                declineTrends('declineRateTrend', lastSixMonthLabels, dataSet);
            } 
        });

        $("#currentBarChart").click(function(){
            var buttonClass = $("#currentBarChart").hasClass('btn btn-light');
            chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            if(buttonClass) {
                $("#currentBarChart").removeClass('btn btn-light');
                $("#currentBarChart").addClass('btn btn-toggle');
                $("#currentTrendChart").removeClass('btn btn-toggle');
                $("#currentTrendChart").addClass('btn btn-light');  
                $(".declineRateTrendContainer").hide();
                $(".declineRateBarContainer").show();
                chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            } 
        });
    }

    //payments this year changes
    function paymentsYearChanges() {
        //top row
        //add data in text()
        $('#totalRevenuePayments').text('$50,164,020');
        $('#totalRevenueTrend').text('12%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalTransactionsPayments').text('400,000');
        $('#totalTransactionsTrend').text('0.8%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#successRatePayments').text('84.80%');
        $('#successRateTrend').text('0.30%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#effectiveRatePayments').text('4%');
        $('#effectiveRateTrend').text('0.30%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //fees by payment doughnut
        //change feesLabels and feesData for timeline
        var feesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var feesData = [30, 54, 77, 18];
        doughnutCharts('feesChart', feesLabels, feesData);

        //declines doughnut
        //change declinesLabels and declinesData for timeline
        var declinesLabels = ['Paypal', 'Authorize.net', 'Stripe', 'Amazon Payments'];
        var declinesData = [2345, 1234, 2132, 1111];
        doughnutCharts('declinesPaymentChart', declinesLabels, declinesData);

        //decline trend - stacked bar
        //change labels, dataSetOne and dataSetTwo for timeline
        var labels = [ "Paypal", "Stripe", "Authorize.net" ];
        var dataSetOne = {
            label: "Success",
            data: [90, 70, 80],
            backgroundColor: "rgb(144,135,192)",
        }

        var dataSetTwo = {
            label: "Failure",
            data: [10, 30, 20],
            backgroundColor: "rgb(150,209,243)",
        }
        
        var buttonTrend = $("#currentTrendChart").hasClass('btn btn-toggle');
        var buttonBar = $("#currentBarChart").hasClass('btn btn-toggle');
        if(buttonTrend) {
            $("#currentBarChart").removeClass('btn btn-light');
            $("#currentBarChart").addClass('btn btn-toggle');
            $("#currentTrendChart").removeClass('btn btn-toggle');
            $("#currentTrendChart").addClass('btn btn-light'); 
            $(".declineRateTrendContainer").hide();
            $(".declineRateBarContainer").show();
        }
        chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);

        //decline trends - trend chart
        //change totalDecline, declineOne, declineTwo and declineThree for timeline
        var totalDecline = {
            label : "Total Decline",
            data : [ 65, 57, 35, 34, 89, 68, 35, 87, 68, 43 ],
            fill : true,
            borderDash: [10,5],
            borderColor : 'rgba(0,0,0,0.09)',
            backgroundColor : 'rgba(0,0,0,0.07)',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineOne = {
            label : "Paypal",
            data : [ 20, 17, 25, 10, 20, 10, 10, 25, 30, 10 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(99,194,242)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineTwo = {
            label : "Stripe",
            data : [ 15, 10, 20, 14, 39, 30, 10, 35, 18, 13 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(170,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var declineThree = {
            label : "Authorize.net",
            data : [ 25, 30, 15, 10, 30, 28, 15, 27, 20, 10 ],
            fill : false,
            tension : 0.2,
            borderColor : 'rgb(217,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var dataSet = [ totalDecline, declineOne, declineTwo, declineThree ]
        declineTrends('declineRateTrend', thisYearLabels, dataSet);

        //revenue table
        //change revenueData for timeline
        var revenueData = [ 
            {
                "Payment Channel"    : "PayPal",
                "Total Transactions" : "224,000",
                "Success Rate"       : "90%",
                "Total Revenue"      : "$12,262,316",
                "Declines"           : "896",
                "Refunds"            : "$193",   
                "Chargebacks"        : "$436.98",
                "Fees"               : "$122,623",
                "Effective Rate"     : "3.8%"
            },
            {
                "Payment Channel"    : "Stripe",
                "Total Transactions" : "144,000",
                "Success Rate"       : "80%",
                "Total Revenue"      : "$9,196,737",
                "Declines"           : "576",
                "Refunds"            : "$1,589",
                "Chargebacks"        : "$688",
                "Fees"               : "$91,967",
                "Effective Rate"     : "2.5%"
            },
            {
                "Payment Channel"    : "Authorize.net",
                "Total Transactions" : "32,000",
                "Success Rate"       : "70%",
                "Total Revenue"      : "$9,196,737",
                "Declines"           : "128",
                "Refunds"            : "$1,445",
                "Chargebacks"        : "$3,097",
                "Fees"               : "$91,967",
                "Effective Rate"     : "2.1%"
            },
            {
                "Payment Channel"    : "Amazon Payments",
                "Total Transactions" : "145,000",
                "Success Rate"       : "85%",
                "Total Revenue"      : "$8,866,606",
                "Declines"           : "500",
                "Refunds"            : "$900",
                "Chargebacks"        : "$300",
                "Fees"               : "$80,000",
                "Effective Rate"     : "2.5%"
            } 
        ]
        tableForRevenue(revenueData);

        //toggling between bar chart and trend
        $("#currentTrendChart").click(function(){
            var buttonClass = $("#currentTrendChart").hasClass('btn btn-light');
            declineTrends('declineRateTrend', thisYearLabels, dataSet);
            if(buttonClass) {
                $("#currentTrendChart").removeClass('btn btn-light');
                $("#currentTrendChart").addClass('btn btn-toggle');
                $("#currentBarChart").removeClass('btn btn-toggle');
                $("#currentBarChart").addClass('btn btn-light');
                $(".declineRateBarContainer").hide();
                $(".declineRateTrendContainer").show();
                declineTrends('declineRateTrend', thisYearLabels, dataSet);
            } 
        });

        $("#currentBarChart").click(function(){
            var buttonClass = $("#currentBarChart").hasClass('btn btn-light');
            chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            if(buttonClass) {
                $("#currentBarChart").removeClass('btn btn-light');
                $("#currentBarChart").addClass('btn btn-toggle');
                $("#currentTrendChart").removeClass('btn btn-toggle');
                $("#currentTrendChart").addClass('btn btn-light');  
                $(".declineRateTrendContainer").hide();
                $(".declineRateBarContainer").show();
                chartForDeclines('declineRateBar',labels,dataSetOne,dataSetTwo);
            } 
        });
    }
});