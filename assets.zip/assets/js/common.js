$(document).ready( function () {

    /*channel comparison chart for sales and products*/

    var labelStringUsed;
    if($('.page-name span').text() == "SALES") {
        labelStringUsed = "Sales";
    } else if($('.page-name span').text() == "PRODUCT REPORTS") {
        labelStringUsed = "Quantity";
    }

    //bar chart function -- common for channels, product category and devices -- everything by sales
    function comparisonChart(idToUse, labels, data) {
        var ctx = $('#'+idToUse[0]);
        var chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                fill: false,
                backgroundColor:[
                                    "rgb(144,135,192)",
                                    "rgb(150,209,243)",
                                    "rgb(244,137,167)"
                ],
                borderWidth:2,
                data: data,
                }]
            },
            options: {
                legend: {
                    display: false,
                },
                scales : {
                    xAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString: idToUse[1]
                        },
                        ticks : {
                            stepSize : 1,
                            min : 0,
                            autoSkip : false
                        }
                    } ],
                    yAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString : 'Sales'
                        },
                        ticks: {
                            beginAtZero : true
                        }
                    } ]
                },
                responsive : true,
                title : {
                    display : false
                }
            }
        });
    }

    //trend chart function -- channels -- everything by sales
    function comparisonTrends() {
        var ctx = $("#channelTrend");
        var totalSalesData = {
            label : "Total Sales",
            data : [ 540, 270, 660, 128, 123, 890, 324, 432, 156, 888, 765, 222 ],
            fill : true,
            borderDash: [10,5],
            borderColor : 'rgba(0,0,0,0.09)',
            backgroundColor : 'rgba(0,0,0,0.07)',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var amazonData = {
            label : "Amazon",
            data : [ 365, 167, 235, 34, 100, 678, 305, 387, 68, 543, 123, 231 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(99,194,242)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var ebayData = {
            label : "eBay",
            data : [ 231, 123, 543, 78, 87, 310, 178, 412, 154, 234, 567, 165 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(170,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var flipkartData = {
            label : "Flipkart",
            data : [ 386, 258, 147, 99, 123, 753, 251, 124, 124, 258, 345, 154 ],
            fill : false,
            tension : 0.2,
            borderColor : 'rgb(217,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var myLineChart = new Chart(ctx, {
            type : 'line',
            data : {
                labels : ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"],
                datasets : [ totalSalesData, amazonData, ebayData, flipkartData ]
            },
            options : {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        boxWidth: 10
                    }
                },
                scales : {
                    xAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString: 'Time'
                        },
                        ticks : {
                            stepSize : 1,
                            min : 0,
                            autoSkip : false
                        }
                    } ],
                    yAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString : 'Sales'
                        }
                    } ]
                }
            }
        });
    }

    //trend chart function -- product category -- everything by sales
    function comparisonProductTrends() {
        var ctx = $("#productTrend");
        var totalSalesData = {
            label : "Total Sales",
            data : [ 540, 270, 660, 128, 123, 890, 324, 432, 156, 888, 765, 222 ],
            fill : true,
            borderDash: [10,5],
            borderColor : 'rgba(0,0,0,0.09)',
            backgroundColor : 'rgba(0,0,0,0.07)',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var bookData = {
            label : "Books",
            data : [ 365, 167, 235, 34, 100, 678, 305, 387, 68, 543, 123, 231 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(99,194,242)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var sportsData = {
            label : "Sports",
            data : [ 231, 123, 543, 78, 87, 310, 178, 412, 154, 234, 567, 165 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(170,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var electronicsData = {
            label : "Electronics",
            data : [ 386, 258, 147, 99, 123, 753, 251, 124, 124, 258, 345, 154 ],
            fill : false,
            tension : 0.2,
            borderColor : 'rgb(217,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var myLineChart = new Chart(ctx, {
            type : 'line',
            data : {
                labels : ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"],
                datasets : [ totalSalesData, bookData, sportsData, electronicsData ]
            },
            options : {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        boxWidth: 10
                    }
                },
                scales : {
                    xAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString: 'Time'
                        },
                        ticks : {
                            stepSize : 1,
                            min : 0,
                            autoSkip : false
                        }
                    } ],
                    yAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString : 'Sales'
                        }
                    } ]
                }
            }
        });
    }

    //trend chart function -- product category -- everything by sales
    function comparisonDeviceTrends() {
        var ctx = $("#deviceTrend");
        var totalSalesData = {
            label : "Total Sales",
            data : [ 540, 270, 660, 128, 123, 890, 324, 432, 156, 888, 765, 222 ],
            fill : true,
            borderDash: [10,5],
            borderColor : 'rgba(0,0,0,0.09)',
            backgroundColor : 'rgba(0,0,0,0.07)',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var desktopData = {
            label : "Desktop",
            data : [ 365, 167, 235, 34, 100, 678, 305, 387, 68, 543, 123, 231 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(99,194,242)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var tabletData = {
            label : "Tablet",
            data : [ 231, 123, 543, 78, 87, 310, 178, 412, 154, 234, 567, 165 ],
            fill : false,
            tension : 0,
            borderColor : 'rgb(170,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var mobileData = {
            label : "Mobile",
            data : [ 386, 258, 147, 99, 123, 753, 251, 124, 124, 258, 345, 154 ],
            fill : false,
            tension : 0.2,
            borderColor : 'rgb(217,62,244)',
            backgroundColor : 'transparent',
            pointRadius : 2,
            pointHoverRadius : 5,
            pointHitRadius : 30,
            pointBorderWidth : 2
        }
        var myLineChart = new Chart(ctx, {
            type : 'line',
            data : {
                labels : ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"],
                datasets : [ totalSalesData, desktopData, tabletData, mobileData ]
            },
            options : {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        boxWidth: 10
                    }
                },
                scales : {
                    xAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString: 'Time'
                        },
                        ticks : {
                            stepSize : 1,
                            min : 0,
                            autoSkip : false
                        }
                    } ],
                    yAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString : 'Sales'
                        }
                    } ]
                }
            }
        });
    }

    //data for channel chart
    var channelId = ["channelChart","Channels"];
    var channelLabels = ["Amazon", "Ebay", "Flipkart"]
    var channelData = [4000, 1000, 300];

    //data for product category chart
    var productCategoryId = ["productChart", "Product Category"];
    var productCategoryLabels = ["Books", "Sports", "Electronics"]
    var productCategoryData = ["3000", "4000", "7000"]

    //data for device chart
    var deviceId = ["deviceChart", "Device"];
    var deviceLabels = ["Desktop", "Tablet", "Mobile"]
    var deviceData = ["1500", "2300", "4003"]

    //drawing channel chart by default
    comparisonChart(channelId, channelLabels, channelData);
    
    //selecting channel, product category or device
    var selectedFilter = "Channel"; 
    $('#selectFilter').change( function() {
        selectedFilter = $('#selectFilter option:selected').text();
        switch(selectedFilter) {
            case "Channel"          :
                                        $('.productChartContainer').hide();
                                        $('.deviceChartContainer').hide();
                                        $('.channelChartContainer').hide();
                                        $('.productTrendContainer').hide();
                                        $('.deviceTrendContainer').hide();
                                        $('.channelTrendContainer').hide();
                                        if($("#currentBarChart").hasClass('btn btn-toggle')) {
                                            $('.channelChartContainer').show();
                                            comparisonChart(channelId, channelLabels, channelData);
                                        } else {
                                            $('.channelTrendContainer').show();
                                            comparisonTrends();
                                        }
                                        
                                        break;
            case "Product Category" :
                                        $('.productChartContainer').hide();
                                        $('.deviceChartContainer').hide();
                                        $('.channelChartContainer').hide();
                                        $('.productTrendContainer').hide();
                                        $('.deviceTrendContainer').hide();
                                        $('.channelTrendContainer').hide();
                                        if($("#currentBarChart").hasClass('btn btn-toggle')) {
                                            $('.productChartContainer').show();
                                            comparisonChart(productCategoryId, productCategoryLabels, productCategoryData);
                                        } else {
                                            $('.productTrendContainer').show();
                                            comparisonProductTrends();
                                        }
                                        break;
            case "Devices"           :
                                        $('.productChartContainer').hide();
                                        $('.deviceChartContainer').hide();
                                        $('.channelChartContainer').hide();
                                        $('.productTrendContainer').hide();
                                        $('.deviceTrendContainer').hide();
                                        $('.channelTrendContainer').hide();
                                        if($("#currentBarChart").hasClass('btn btn-toggle')) {
                                            $('.deviceChartContainer').show();
                                            comparisonChart(deviceId, deviceLabels, deviceData);
                                        } else {
                                            $('.deviceTrendContainer').show();
                                            comparisonDeviceTrends();
                                        }
                                        break;
            default                 :
                                        $('.productChartContainer').hide();
                                        $('.deviceChartContainer').hide();
                                        $('.channelChartContainer').hide();
                                        $('.productTrendContainer').hide();
                                        $('.deviceTrendContainer').hide();
                                        $('.channelTrendContainer').hide();
                                        if($("#barTrendChart").hasClass('btn btn-toggle')) {
                                            $('.channelChartContainer').show();
                                            comparisonChart(channelId, channelLabels, channelData);
                                        } else {
                                            $('.channelTrendContainer').show();
                                            comparisonTrends();
                                        }
                                        break;
        }
    })

    //toggling between bar chart and trend
    $("#currentTrendChart").click(function(){
        var buttonClass = $("#currentTrendChart").hasClass('btn btn-light');
        if(buttonClass) {
            $("#currentTrendChart").removeClass('btn btn-light');
            $("#currentTrendChart").addClass('btn btn-toggle');
            $("#currentBarChart").removeClass('btn btn-toggle');
            $("#currentBarChart").addClass('btn btn-light');
            switch(selectedFilter) {
                case "Channel"          :
                                            $('.channelChartContainer').hide();
                                            $('.productChartContainer').hide();
                                            $('.deviceChartContainer').hide();
                                            $('.productTrendContainer').hide();
                                            $('.deviceTrendContainer').hide();
                                            $('.channelTrendContainer').show();
                                            comparisonTrends();
                                            break;
                case "Product Category" :
                                            $('.channelChartContainer').hide();
                                            $('.productChartContainer').hide();
                                            $('.deviceChartContainer').hide();
                                            $('.deviceTrendContainer').hide();
                                            $('.channelTrendContainer').hide();
                                            $('.productTrendContainer').show();
                                            comparisonProductTrends();
                                            break;
                case "Devices"          :
                                            $('.channelChartContainer').hide();
                                            $('.productChartContainer').hide();
                                            $('.deviceChartContainer').hide();
                                            $('.channelTrendContainer').hide();
                                            $('.productTrendContainer').hide();
                                            $('.deviceTrendContainer').show();
                                            comparisonDeviceTrends();
                                            break;
                default                 :
                                            $('.channelChartContainer').hide();
                                            $('.productChartContainer').hide();
                                            $('.deviceChartContainer').hide();
                                            $('.productTrendContainer').hide();
                                            $('.deviceTrendContainer').hide();
                                            $('.channelTrendContainer').show();
                                            comparisonTrends();
                                            break;
            }
        } 
    });

    $("#currentBarChart").click(function(){
        var buttonClass = $("#currentBarChart").hasClass('btn btn-light');
        if(buttonClass) {
            $("#currentBarChart").removeClass('btn btn-light');
            $("#currentBarChart").addClass('btn btn-toggle');
            $("#currentTrendChart").removeClass('btn btn-toggle');
            $("#currentTrendChart").addClass('btn btn-light');  
            switch(selectedFilter) {
                case "Channel"          :
                                            $('.productChartContainer').hide();
                                            $('.deviceChartContainer').hide();
                                            $('.productTrendContainer').hide();
                                            $('.deviceTrendContainer').hide();
                                            $('.channelTrendContainer').hide();
                                            $('.channelChartContainer').show();
                                            comparisonChart(channelId, channelLabels, channelData);
                                            break;
                case "Product Category" :
                                            $('.deviceChartContainer').hide();
                                            $('.productTrendContainer').hide();
                                            $('.deviceTrendContainer').hide();
                                            $('.channelTrendContainer').hide();
                                            $('.channelChartContainer').hide();
                                            $('.productChartContainer').show();
                                            comparisonChart(productCategoryId, productCategoryLabels, productCategoryData);
                                            break;
                case "Devices"          :
                                            $('.productTrendContainer').hide();
                                            $('.deviceTrendContainer').hide();
                                            $('.channelTrendContainer').hide();
                                            $('.channelChartContainer').hide();
                                            $('.productChartContainer').hide();
                                            $('.deviceChartContainer').show();
                                            comparisonChart(deviceId, deviceLabels, deviceData);
                                            break;
                default                 :
                                            $('.productChartContainer').hide();
                                            $('.deviceChartContainer').hide();
                                            $('.productTrendContainer').hide();
                                            $('.deviceTrendContainer').hide();
                                            $('.channelTrendContainer').hide();
                                            $('.channelChartContainer').show();
                                            comparisonChart(channelId, channelLabels, channelData);
                                            break;
            }
        } 
    });
});