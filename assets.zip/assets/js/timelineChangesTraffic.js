$(document).ready(function(){
    
    var yesterdayLabels = ['25-09-2018'];
    var thisWeekLabels = ['Sunday', 'Monday', 'Tuesday'];
    var lastWeekLabels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var thisMonthLabels = ['Sep'];
    var lastMonthLabels = ['August'];
    var lastSixMonthLabels = ["Mar", "Apr", "May", "June", "July", "Aug"];
    var thisYearLabels = [ "Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct" ];

    trafficThisMonthChanges();
    tableAlignment();
    $('.time-range').change(function() {
        var selectedRange = $(this).val();
        // alert(selectedRange);
        switch(selectedRange) {
            case 'Yesterday' :
                trafficYesterdayChanges();
                tableAlignment();
                break;
            case 'This Week'    :
                trafficThisWeekChanges();
                tableAlignment();
                break;
            case 'Last week'    :
               // trafficLastWeekChanges();
                break;
            case 'This Month'   :
                trafficThisMonthChanges();
                tableAlignment();
                break;
            case 'Last month'   :
               // trafficLastMonthChanges();
                break;
            case 'Last 6 month' :
               // trafficLastSixMonthChanges();
                break;
            case 'Year'    :
                trafficYearChanges();
                tableAlignment();
                break;
            default             :
                trafficThisMonthChanges();
                tableAlignment();
                break;
        }
    });

    //traffic yesterday changes
    function trafficYesterdayChanges() {
        
        //top row
        //add data in text()
        $('#totalVisitsTraffic').text('8,853');
        $('#totalVisitTrend').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalSessionsTraffic').text('4,806');
        $('#sessionTrend').text('0.25%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#totalPagesPerSessionsTraffic').text('10');
        $('#pagesPerSessionTrend').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalAvgDurationTraffic').text('1:12:30');
        $('#avgDurationTrend').text('0.25%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //bounceRate
        $('#bounceRate').text('23%');

        //user pie chart
        var userData = [55, 40];
        bounceRate('visitor-stats-chart', userData);

        //site specifics
        //add data in text()
        $('#avgPageLoadTime').text('10');
        $('#avgServerResponseTime').text('5');
        $('#avgRedirectionTime').text('0.05');
        $('#crashes').text('1');
        $('#exceptions').text('0');

        //country map
        //change country data for timeline
        var countryData = {"af":"16.63","al":"11.58","dz":"158.97","ao":"85.81","ag":"1.1","ar":"351.02","am":"8.83","au":"1219.72","at":"366.26","az":"52.17","bs":"7.54","bh":"21.73","bd":"105.4","bb":"3.96","by":"52.89","be":"461.33","bz":"1.43","bj":"6.49","bt":"1.4","bo":"19.18","ba":"16.2","bw":"12.5","br":"2023.53","bn":"11.96","bg":"44.84","bf":"8.67","bi":"1.47","kh":"11.36","cm":"21.88","ca":"1563.66","cv":"1.57","cf":"2.11","td":"7.59","cl":"199.18","cn":"5745.13","co":"283.11","km":"0.56","cd":"12.6","cg":"11.88","cr":"35.02","ci":"22.38","hr":"59.92","cy":"22.75","cz":"195.23","dk":"304.56","dj":"1.14","dm":"0.38","do":"50.87","ec":"61.49","eg":"216.83","sv":"21.8","gq":"14.55","er":"2.25","ee":"19.22","et":"30.94","fj":"3.15","fi":"231.98","fr":"2555.44","ga":"12.56","gm":"1.04","ge":"11.23","de":"3305.9","gh":"18.06","gr":"305.01","gd":"0.65","gt":"40.77","gn":"4.34","gw":"0.83","gy":"2.2","ht":"6.5","hn":"15.34","hk":"226.49","hu":"132.28","is":"12.77","in":"1430.02","id":"695.06","ir":"337.9","iq":"84.14","ie":"204.14","il":"201.25","it":"2036.69","jm":"13.74","jp":"5390.9","jo":"27.13","kz":"129.76","ke":"32.42","ki":"0.15","kr":"986.26","undefined":"5.73","kw":"117.32","kg":"4.44","la":"6.34","lv":"23.39","lb":"39.15","ls":"1.8","lr":"0.98","ly":"77.91","lt":"35.73","lu":"52.43","mk":"9.58","mg":"8.33","mw":"5.04","my":"218.95","mv":"1.43","ml":"9.08","mt":"7.8","mr":"3.49","mu":"9.43","mx":"1004.04","md":"5.36","mn":"5.81","me":"3.88","ma":"91.7","mz":"10.21","mm":"35.65","na":"11.45","np":"15.11","nl":"770.31","nz":"138","ni":"6.38","ne":"5.6","ng":"206.66","no":"413.51","om":"53.78","pk":"174.79","pa":"27.2","pg":"8.81","py":"17.17","pe":"153.55","ph":"189.06","pl":"438.88","pt":"223.7","qa":"126.52","ro":"158.39","ru":"1476.91","rw":"5.69","ws":"0.55","st":"0.19","sa":"434.44","sn":"12.66","rs":"38.92","sc":"0.92","sl":"1.9","sg":"217.38","sk":"86.26","si":"46.44","sb":"0.67","za":"354.41","es":"1374.78","lk":"48.24","kn":"0.56","lc":"1","vc":"0.58","sd":"65.93","sr":"3.3","sz":"3.17","se":"444.59","ch":"522.44","sy":"59.63","tw":"426.98","tj":"5.58","tz":"22.43","th":"312.61","tl":"0.62","tg":"3.07","to":"0.3","tt":"21.2","tn":"43.86","tr":"729.05","tm":0,"ug":"17.12","ua":"136.56","ae":"239.65","gb":"2258.57","us":"14624.18","uy":"40.71","uz":"37.72","vu":"0.72","ve":"285.21","vn":"101.99","ye":"30.02","zm":"15.69","zw":"5.57"};
        mapForCountry(countryData);

        //acquisition report table
        //change acquisition data values for timeline
        var acquisitionData = [
            {
                "Source" : "Organic Search",
                "Clicks" : "83",
                "Cost" : "$21",
                "CPC" : "$0.25",
                "Users" :"3,458",
                "New Users" :"2,200",
                "Sessions" :"3,721",
                "Bounce Rate" :"24.00%",
                "Pages/Session" :"3",
                "Avg Session Duration" :"01:12",
                "Conversion Rate" :"1.00%",
                "Transactions" :"99",
                "Revenue" :"$916"
            }, {
                "Source" : "Direct",
                "Clicks" : "56",
                "Cost" : "$24",
                "CPC" : "$0.43",
                "Users" :"2,464",
                "New Users" :"1,204",
                "Sessions" :"212",
                "Bounce Rate" :"20.00%",
                "Pages/Session" :"2",
                "Avg Session Duration" :"01:02:25",
                "Conversion Rate" :"1.00%",
                "Transactions" :"49",
                "Revenue" :"$1,110 "
            }, {
                "Source" : "Social",
                "Clicks" : "83",
                "Cost" : "$19",
                "CPC" : "$0.23",
                "Users" :"2,190",
                "New Users" :"881",
                "Sessions" :"489",
                "Bounce Rate" :"18.00%",
                "Pages/Session" :"1",
                "Avg Session Duration" :"00:25",
                "Conversion Rate" :"0.11%",
                "Transactions" :"66",
                "Revenue" :"$986"
            }, {
                "Source" : "Referral",
                "Clicks" : "70",
                "Cost" : "$21",
                "CPC" : "$0.30",
                "Users" :"741",
                "New Users" :"54",
                "Sessions" :"384",
                "Bounce Rate" :"6.00%",
                "Pages/Session" :"1",
                "Avg Session Duration" :"00:25",
                "Conversion Rate" :"0.50%",
                "Transactions" :"54",
                "Revenue" :"$221"
            }
        ]
        tableForAcquisition(acquisitionData);

        var platformData = [
            {
                "Day/Month/Year"    : "2018 July",
                "Sessions"          : "36",
                "Users"             : "34",
                "Page Views"        : "2",
                "Conversion Rate"   : "0.20%"
            },
            {
                "Day/Month/Year" : "2018 June",
                "Sessions"          : "6",
                "Users"             : "5",
                "Page Views"        : "5",
                "Conversion Rate"   : "0.20%"
            },
            {
                "Day/Month/Year" : "2018 May",
                "Sessions"          : "14",
                "Users"             : "11",
                "Page Views"        : "6",
                "Conversion Rate"   : "0.60%"
            },
            {
                "Day/Month/Year" : "2018 Apr",
                "Sessions"          : "12",
                "Users"             : "8",
                "Page Views"        : "2",
                "Conversion Rate"   : "0.75%"
            }
        ]
        tableForPlatform(platformData);
    }

    //traffic this week changes
    function trafficThisWeekChanges() {
        
        //top row
        //add data in text()
        $('#totalVisitsTraffic').text('44,265');
        $('#totalVisitTrend').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalSessionsTraffic').text('24,030');
        $('#sessionTrend').text('0.25%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#totalPagesPerSessionsTraffic').text('12');
        $('#pagesPerSessionTrend').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalAvgDurationTraffic').text('1:12:30');
        $('#avgDurationTrend').text('0.25%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //bounceRate
        $('#bounceRate').text('29%');

        //user pie chart
        var userData = [55, 40];
        bounceRate('visitor-stats-chart', userData);

        //site specifics
        //add data in text()
        $('#avgPageLoadTime').text('9');
        $('#avgServerResponseTime').text('5');
        $('#avgRedirectionTime').text('0.12');
        $('#crashes').text('2');
        $('#exceptions').text('2');

        //country map
        //change country data for timeline
        var countryData = {"af":"16.63","al":"11.58","dz":"158.97","ao":"85.81","ag":"1.1","ar":"351.02","am":"8.83","au":"1219.72","at":"366.26","az":"52.17","bs":"7.54","bh":"21.73","bd":"105.4","bb":"3.96","by":"52.89","be":"461.33","bz":"1.43","bj":"6.49","bt":"1.4","bo":"19.18","ba":"16.2","bw":"12.5","br":"2023.53","bn":"11.96","bg":"44.84","bf":"8.67","bi":"1.47","kh":"11.36","cm":"21.88","ca":"1563.66","cv":"1.57","cf":"2.11","td":"7.59","cl":"199.18","cn":"5745.13","co":"283.11","km":"0.56","cd":"12.6","cg":"11.88","cr":"35.02","ci":"22.38","hr":"59.92","cy":"22.75","cz":"195.23","dk":"304.56","dj":"1.14","dm":"0.38","do":"50.87","ec":"61.49","eg":"216.83","sv":"21.8","gq":"14.55","er":"2.25","ee":"19.22","et":"30.94","fj":"3.15","fi":"231.98","fr":"2555.44","ga":"12.56","gm":"1.04","ge":"11.23","de":"3305.9","gh":"18.06","gr":"305.01","gd":"0.65","gt":"40.77","gn":"4.34","gw":"0.83","gy":"2.2","ht":"6.5","hn":"15.34","hk":"226.49","hu":"132.28","is":"12.77","in":"1430.02","id":"695.06","ir":"337.9","iq":"84.14","ie":"204.14","il":"201.25","it":"2036.69","jm":"13.74","jp":"5390.9","jo":"27.13","kz":"129.76","ke":"32.42","ki":"0.15","kr":"986.26","undefined":"5.73","kw":"117.32","kg":"4.44","la":"6.34","lv":"23.39","lb":"39.15","ls":"1.8","lr":"0.98","ly":"77.91","lt":"35.73","lu":"52.43","mk":"9.58","mg":"8.33","mw":"5.04","my":"218.95","mv":"1.43","ml":"9.08","mt":"7.8","mr":"3.49","mu":"9.43","mx":"1004.04","md":"5.36","mn":"5.81","me":"3.88","ma":"91.7","mz":"10.21","mm":"35.65","na":"11.45","np":"15.11","nl":"770.31","nz":"138","ni":"6.38","ne":"5.6","ng":"206.66","no":"413.51","om":"53.78","pk":"174.79","pa":"27.2","pg":"8.81","py":"17.17","pe":"153.55","ph":"189.06","pl":"438.88","pt":"223.7","qa":"126.52","ro":"158.39","ru":"1476.91","rw":"5.69","ws":"0.55","st":"0.19","sa":"434.44","sn":"12.66","rs":"38.92","sc":"0.92","sl":"1.9","sg":"217.38","sk":"86.26","si":"46.44","sb":"0.67","za":"354.41","es":"1374.78","lk":"48.24","kn":"0.56","lc":"1","vc":"0.58","sd":"65.93","sr":"3.3","sz":"3.17","se":"444.59","ch":"522.44","sy":"59.63","tw":"426.98","tj":"5.58","tz":"22.43","th":"312.61","tl":"0.62","tg":"3.07","to":"0.3","tt":"21.2","tn":"43.86","tr":"729.05","tm":0,"ug":"17.12","ua":"136.56","ae":"239.65","gb":"2258.57","us":"14624.18","uy":"40.71","uz":"37.72","vu":"0.72","ve":"285.21","vn":"101.99","ye":"30.02","zm":"15.69","zw":"5.57"};
        mapForCountry(countryData);

        //acquisition report table
        //change acquisition data values for timeline
        var acquisitionData = [
            {
                "Source" : "Organic Search",
                "Clicks" : "427",
                "Cost" : "$55",
                "CPC" : "$0.28",
                "Users" :"20,674",
                "New Users" :"13,125",
                "Sessions" :"10,254",
                "Bounce Rate" :"39.60%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:01:12",
                "Conversion Rate" :"1.46%",
                "Transactions" :"524",
                "Revenue" :"$5,421"
            }, {
                "Source" : "Direct",
                "Clicks" : "262",
                "Cost" : "$72",
                "CPC" : "$0.13",
                "Users" :"14,709",
                "New Users" :"7,154",
                "Sessions" :"1200",
                "Bounce Rate" :"61.80%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"01:12:25",
                "Conversion Rate" :"1.07%",
                "Transactions" :"221",
                "Revenue" :"$6,589"
            }, {
                "Source" : "Social",
                "Clicks" : "423",
                "Cost" : "$43",
                "CPC" : "$0.23",
                "Users" :"13,068",
                "New Users" :"5,214",
                "Sessions" :"500",
                "Bounce Rate" :"64%",
                "Pages/Session" :"3.21",
                "Avg Session Duration" :"00:00:25",
                "Conversion Rate" :"0.11%",
                "Transactions" :"325",
                "Revenue" :"$5,841"
            }, {
                "Source" : "Referral",
                "Clicks" : "345",
                "Cost" : "$56",
                "CPC" : "$0.56",
                "Users" :"4,374",
                "New Users" :"250",
                "Sessions" :"430",
                "Bounce Rate" :"26.11%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:00:25",
                "Conversion Rate" :"1.00%",
                "Transactions" :"251",
                "Revenue" :"$1,254"
            }
        ]
        tableForAcquisition(acquisitionData);

        var platformData = [
            {
                "Day/Month/Year"    : "2018 July",
                "Sessions"          : "3900",
                "Users"             : "3600",
                "Page Views"        : "300",
                "Conversion Rate"   : "2.00%"
            },
            {			
                "Day/Month/Year" : "2018 June",
                "Sessions"          : "600",
                "Users"             : "600",
                "Page Views"        : "300",
                "Conversion Rate"   : "3.10%"
            },
            {			
                "Day/Month/Year" : "2018 May",
                "Sessions"          : "1500",
                "Users"             : "1200",
                "Page Views"        : "600",
                "Conversion Rate"   : "1.80%"
            },
            {			
                "Day/Month/Year" : "2018 Apr",
                "Sessions"          : "1200",
                "Users"             : "900",
                "Page Views"        : "300",
                "Conversion Rate"   : "1.20%"
            }
        ]
        tableForPlatform(platformData);
    }

    //traffic last week changes
    function trafficLastWeekChanges() {
        
        //top row
        //add data in text()
        $('#totalVisitsTraffic').text('');
        $('#totalVisitTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalSessionsTraffic').text('');
        $('#sessionTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#totalPagesPerSessionsTraffic').text('');
        $('#pagesPerSessionTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalAvgDurationTraffic').text('');
        $('#avgDurationTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //bounceRate
        $('#bounceRate').text('%');

        //user pie chart
        var userData = [55, 40];
        bounceRate('visitor-stats-chart', userData);

        //site specifics
        //add data in text()
        $('#avgPageLoadTime').text();
        $('#avgServerResponseTime').text();
        $('#avgRedirectionTime').text();
        $('#crashes').text();
        $('#exceptions').text();

        //country map
        //change country data for timeline
        var countryData = {"af":"16.63","al":"11.58","dz":"158.97","ao":"85.81","ag":"1.1","ar":"351.02","am":"8.83","au":"1219.72","at":"366.26","az":"52.17","bs":"7.54","bh":"21.73","bd":"105.4","bb":"3.96","by":"52.89","be":"461.33","bz":"1.43","bj":"6.49","bt":"1.4","bo":"19.18","ba":"16.2","bw":"12.5","br":"2023.53","bn":"11.96","bg":"44.84","bf":"8.67","bi":"1.47","kh":"11.36","cm":"21.88","ca":"1563.66","cv":"1.57","cf":"2.11","td":"7.59","cl":"199.18","cn":"5745.13","co":"283.11","km":"0.56","cd":"12.6","cg":"11.88","cr":"35.02","ci":"22.38","hr":"59.92","cy":"22.75","cz":"195.23","dk":"304.56","dj":"1.14","dm":"0.38","do":"50.87","ec":"61.49","eg":"216.83","sv":"21.8","gq":"14.55","er":"2.25","ee":"19.22","et":"30.94","fj":"3.15","fi":"231.98","fr":"2555.44","ga":"12.56","gm":"1.04","ge":"11.23","de":"3305.9","gh":"18.06","gr":"305.01","gd":"0.65","gt":"40.77","gn":"4.34","gw":"0.83","gy":"2.2","ht":"6.5","hn":"15.34","hk":"226.49","hu":"132.28","is":"12.77","in":"1430.02","id":"695.06","ir":"337.9","iq":"84.14","ie":"204.14","il":"201.25","it":"2036.69","jm":"13.74","jp":"5390.9","jo":"27.13","kz":"129.76","ke":"32.42","ki":"0.15","kr":"986.26","undefined":"5.73","kw":"117.32","kg":"4.44","la":"6.34","lv":"23.39","lb":"39.15","ls":"1.8","lr":"0.98","ly":"77.91","lt":"35.73","lu":"52.43","mk":"9.58","mg":"8.33","mw":"5.04","my":"218.95","mv":"1.43","ml":"9.08","mt":"7.8","mr":"3.49","mu":"9.43","mx":"1004.04","md":"5.36","mn":"5.81","me":"3.88","ma":"91.7","mz":"10.21","mm":"35.65","na":"11.45","np":"15.11","nl":"770.31","nz":"138","ni":"6.38","ne":"5.6","ng":"206.66","no":"413.51","om":"53.78","pk":"174.79","pa":"27.2","pg":"8.81","py":"17.17","pe":"153.55","ph":"189.06","pl":"438.88","pt":"223.7","qa":"126.52","ro":"158.39","ru":"1476.91","rw":"5.69","ws":"0.55","st":"0.19","sa":"434.44","sn":"12.66","rs":"38.92","sc":"0.92","sl":"1.9","sg":"217.38","sk":"86.26","si":"46.44","sb":"0.67","za":"354.41","es":"1374.78","lk":"48.24","kn":"0.56","lc":"1","vc":"0.58","sd":"65.93","sr":"3.3","sz":"3.17","se":"444.59","ch":"522.44","sy":"59.63","tw":"426.98","tj":"5.58","tz":"22.43","th":"312.61","tl":"0.62","tg":"3.07","to":"0.3","tt":"21.2","tn":"43.86","tr":"729.05","tm":0,"ug":"17.12","ua":"136.56","ae":"239.65","gb":"2258.57","us":"14624.18","uy":"40.71","uz":"37.72","vu":"0.72","ve":"285.21","vn":"101.99","ye":"30.02","zm":"15.69","zw":"5.57"};
        mapForCountry(countryData);

        //acquisition report table
        //change acquisition data values for timeline
        var acquisitionData = [
            {
                "Source" : "Organic Search",
                "Clicks" : "4",
                "Cost" : "$55.17",
                "CPC" : "$0.28",
                "Users" :"20,674",
                "New Users" :"13,125",
                "Sessions" :"10,254",
                "Bounce Rate" :"39.60%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:01:12",
                "Conversion Rate" :"1.46%",
                "Transactions" :"524",
                "Revenue" :"$5421"
            }, {
                "Source" : "Direct",
                "Clicks" : "2",
                "Cost" : "$72.17",
                "CPC" : "$0.13",
                "Users" :"14,709",
                "New Users" :"7,154",
                "Sessions" :"900",
                "Bounce Rate" :"61.81%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:01:25",
                "Conversion Rate" :"1.07%",
                "Transactions" :"221",
                "Revenue" :"$6589"
            }, {
                "Source" : "Social",
                "Clicks" : "4",
                "Cost" : "$43.17",
                "CPC" : "$0.23",
                "Users" :"13,068",
                "New Users" :"5,214",
                "Sessions" :"500",
                "Bounce Rate" :"64.47%",
                "Pages/Session" :"3.21",
                "Avg Session Duration" :"00:00:25",
                "Conversion Rate" :"0.11%",
                "Transactions" :"325",
                "Revenue" :"$5841"
            }, {
                "Source" : "Referral",
                "Clicks" : "5",
                "Cost" : "$56.17",
                "CPC" : "$0.56",
                "Users" :"4,374",
                "New Users" :"250",
                "Sessions" :"430",
                "Bounce Rate" :"26.11%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:00:60",
                "Conversion Rate" :"6.59%",
                "Transactions" :"251",
                "Revenue" :"$1254"
            }
        ]
        tableForAcquisition(acquisitionData);
    }

    //traffic this month changes
    function trafficThisMonthChanges() {
        
        //top row
        //add data in text()
        $('#totalVisitsTraffic').text('177,060');
        $('#totalVisitTrend').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalSessionsTraffic').text('96,120');
        $('#sessionTrend').text('0.25%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#totalPagesPerSessionsTraffic').text('14');
        $('#pagesPerSessionTrend').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalAvgDurationTraffic').text('1:11:22');
        $('#avgDurationTrend').text('0.25%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //bounceRate
        $('#bounceRate').text('23%');

        //user pie chart
        var userData = [55, 40];
        bounceRate('visitor-stats-chart', userData);

        //site specifics
        //add data in text()
        $('#avgPageLoadTime').text('7');
        $('#avgServerResponseTime').text('4.2');
        $('#avgRedirectionTime').text('0.08');
        $('#crashes').text('2');
        $('#exceptions').text('2');

        //country map
        //change country data for timeline
        var countryData = {"af":"16.63","al":"11.58","dz":"158.97","ao":"85.81","ag":"1.1","ar":"351.02","am":"8.83","au":"1219.72","at":"366.26","az":"52.17","bs":"7.54","bh":"21.73","bd":"105.4","bb":"3.96","by":"52.89","be":"461.33","bz":"1.43","bj":"6.49","bt":"1.4","bo":"19.18","ba":"16.2","bw":"12.5","br":"2023.53","bn":"11.96","bg":"44.84","bf":"8.67","bi":"1.47","kh":"11.36","cm":"21.88","ca":"1563.66","cv":"1.57","cf":"2.11","td":"7.59","cl":"199.18","cn":"5745.13","co":"283.11","km":"0.56","cd":"12.6","cg":"11.88","cr":"35.02","ci":"22.38","hr":"59.92","cy":"22.75","cz":"195.23","dk":"304.56","dj":"1.14","dm":"0.38","do":"50.87","ec":"61.49","eg":"216.83","sv":"21.8","gq":"14.55","er":"2.25","ee":"19.22","et":"30.94","fj":"3.15","fi":"231.98","fr":"2555.44","ga":"12.56","gm":"1.04","ge":"11.23","de":"3305.9","gh":"18.06","gr":"305.01","gd":"0.65","gt":"40.77","gn":"4.34","gw":"0.83","gy":"2.2","ht":"6.5","hn":"15.34","hk":"226.49","hu":"132.28","is":"12.77","in":"1430.02","id":"695.06","ir":"337.9","iq":"84.14","ie":"204.14","il":"201.25","it":"2036.69","jm":"13.74","jp":"5390.9","jo":"27.13","kz":"129.76","ke":"32.42","ki":"0.15","kr":"986.26","undefined":"5.73","kw":"117.32","kg":"4.44","la":"6.34","lv":"23.39","lb":"39.15","ls":"1.8","lr":"0.98","ly":"77.91","lt":"35.73","lu":"52.43","mk":"9.58","mg":"8.33","mw":"5.04","my":"218.95","mv":"1.43","ml":"9.08","mt":"7.8","mr":"3.49","mu":"9.43","mx":"1004.04","md":"5.36","mn":"5.81","me":"3.88","ma":"91.7","mz":"10.21","mm":"35.65","na":"11.45","np":"15.11","nl":"770.31","nz":"138","ni":"6.38","ne":"5.6","ng":"206.66","no":"413.51","om":"53.78","pk":"174.79","pa":"27.2","pg":"8.81","py":"17.17","pe":"153.55","ph":"189.06","pl":"438.88","pt":"223.7","qa":"126.52","ro":"158.39","ru":"1476.91","rw":"5.69","ws":"0.55","st":"0.19","sa":"434.44","sn":"12.66","rs":"38.92","sc":"0.92","sl":"1.9","sg":"217.38","sk":"86.26","si":"46.44","sb":"0.67","za":"354.41","es":"1374.78","lk":"48.24","kn":"0.56","lc":"1","vc":"0.58","sd":"65.93","sr":"3.3","sz":"3.17","se":"444.59","ch":"522.44","sy":"59.63","tw":"426.98","tj":"5.58","tz":"22.43","th":"312.61","tl":"0.62","tg":"3.07","to":"0.3","tt":"21.2","tn":"43.86","tr":"729.05","tm":0,"ug":"17.12","ua":"136.56","ae":"239.65","gb":"2258.57","us":"14624.18","uy":"40.71","uz":"37.72","vu":"0.72","ve":"285.21","vn":"101.99","ye":"30.02","zm":"15.69","zw":"5.57"};
        mapForCountry(countryData);

        //acquisition report table
        //change acquisition data values for timeline
        var acquisitionData = [
            {
                "Source" : "Organic Search",
                "Clicks" : "1,660",
                "Cost" : "$420",
                "CPC" : "$0.28",
                "Users" :"60,160",
                "New Users" :"44,000",
                "Sessions" :"74,420",
                "Bounce Rate" :"24.15%",
                "Pages/Session" :"5",
                "Avg Session Duration" :"00:01:12",
                "Conversion Rate" :"1.46%",
                "Transactions" :"1,980",
                "Revenue" :"$18,320"
            }, {
                "Source" : "Direct",
                "Clicks" : "1,120",
                "Cost" : "$480",
                "CPC" : "$0.13",
                "Users" :"49,280",
                "New Users" :"24,080",
                "Sessions" :"4,240",
                "Bounce Rate" :"61.81%",
                "Pages/Session" :"4",
                "Avg Session Duration" :"00:01:25",
                "Conversion Rate" :"1.07%",
                "Transactions" :"980",
                "Revenue" :"$22,200"
            }, {
                "Source" : "Social",
                "Clicks" : "1,160",
                "Cost" : "$380",
                "CPC" : "$0.23",
                "Users" :"43,800",
                "New Users" :"17,620",
                "Sessions" :"9,780",
                "Bounce Rate" :"64.47%",
                "Pages/Session" :"3.21",
                "Avg Session Duration" :"00:00:25",
                "Conversion Rate" :"0.11%",
                "Transactions" :"1,320",
                "Revenue" :"$19,720"
            }, {
                "Source" : "Referral",
                "Clicks" : "1,400",
                "Cost" : "$420",
                "CPC" : "$0.56",
                "Users" :"14,820",
                "New Users" :"1,080",
                "Sessions" :"7,680",
                "Bounce Rate" :"26.11%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:00:60",
                "Conversion Rate" :"6.59%",
                "Transactions" :"1,080",
                "Revenue" :"$4,420"
            }
        ]
        tableForAcquisition(acquisitionData);

        var platformData = [
            {			
                "Day/Month/Year"    : "2018 July",
                "Sessions"          : "3987",
                "Users"             : "3639",
                "Page Views"        : "300",
                "Conversion Rate"   : "0.32%"
            },
            {						
                "Day/Month/Year" : "2018 June",
                "Sessions"          : "656",
                "Users"             : "544",
                "Page Views"        : "394",
                "Conversion Rate"   : "0.73%"
            },
            {						
                "Day/Month/Year" : "2018 May",
                "Sessions"          : "1535",
                "Users"             : "1178",
                "Page Views"        : "600",
                "Conversion Rate"   : "0.60%"
            },
            {						
                "Day/Month/Year" : "2018 Apr",
                "Sessions"          : "1304",
                "Users"             : "961",
                "Page Views"        : "300",
                "Conversion Rate"   : "1.20%"
            }
        ]
        tableForPlatform(platformData);
    }

    //traffic last month changes
    function trafficLastMonthChanges() {
        
        //top row
        //add data in text()
        $('#totalVisitsTraffic').text('');
        $('#totalVisitTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalSessionsTraffic').text('');
        $('#sessionTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#totalPagesPerSessionsTraffic').text('');
        $('#pagesPerSessionTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalAvgDurationTraffic').text('');
        $('#avgDurationTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //bounceRate
        $('#bounceRate').text('%');

        //user pie chart
        var userData = [55, 40];
        bounceRate('visitor-stats-chart', userData);

        //site specifics
        //add data in text()
        $('#avgPageLoadTime').text();
        $('#avgServerResponseTime').text();
        $('#avgRedirectionTime').text();
        $('#crashes').text();
        $('#exceptions').text();

        //country map
        //change country data for timeline
        var countryData = {"af":"16.63","al":"11.58","dz":"158.97","ao":"85.81","ag":"1.1","ar":"351.02","am":"8.83","au":"1219.72","at":"366.26","az":"52.17","bs":"7.54","bh":"21.73","bd":"105.4","bb":"3.96","by":"52.89","be":"461.33","bz":"1.43","bj":"6.49","bt":"1.4","bo":"19.18","ba":"16.2","bw":"12.5","br":"2023.53","bn":"11.96","bg":"44.84","bf":"8.67","bi":"1.47","kh":"11.36","cm":"21.88","ca":"1563.66","cv":"1.57","cf":"2.11","td":"7.59","cl":"199.18","cn":"5745.13","co":"283.11","km":"0.56","cd":"12.6","cg":"11.88","cr":"35.02","ci":"22.38","hr":"59.92","cy":"22.75","cz":"195.23","dk":"304.56","dj":"1.14","dm":"0.38","do":"50.87","ec":"61.49","eg":"216.83","sv":"21.8","gq":"14.55","er":"2.25","ee":"19.22","et":"30.94","fj":"3.15","fi":"231.98","fr":"2555.44","ga":"12.56","gm":"1.04","ge":"11.23","de":"3305.9","gh":"18.06","gr":"305.01","gd":"0.65","gt":"40.77","gn":"4.34","gw":"0.83","gy":"2.2","ht":"6.5","hn":"15.34","hk":"226.49","hu":"132.28","is":"12.77","in":"1430.02","id":"695.06","ir":"337.9","iq":"84.14","ie":"204.14","il":"201.25","it":"2036.69","jm":"13.74","jp":"5390.9","jo":"27.13","kz":"129.76","ke":"32.42","ki":"0.15","kr":"986.26","undefined":"5.73","kw":"117.32","kg":"4.44","la":"6.34","lv":"23.39","lb":"39.15","ls":"1.8","lr":"0.98","ly":"77.91","lt":"35.73","lu":"52.43","mk":"9.58","mg":"8.33","mw":"5.04","my":"218.95","mv":"1.43","ml":"9.08","mt":"7.8","mr":"3.49","mu":"9.43","mx":"1004.04","md":"5.36","mn":"5.81","me":"3.88","ma":"91.7","mz":"10.21","mm":"35.65","na":"11.45","np":"15.11","nl":"770.31","nz":"138","ni":"6.38","ne":"5.6","ng":"206.66","no":"413.51","om":"53.78","pk":"174.79","pa":"27.2","pg":"8.81","py":"17.17","pe":"153.55","ph":"189.06","pl":"438.88","pt":"223.7","qa":"126.52","ro":"158.39","ru":"1476.91","rw":"5.69","ws":"0.55","st":"0.19","sa":"434.44","sn":"12.66","rs":"38.92","sc":"0.92","sl":"1.9","sg":"217.38","sk":"86.26","si":"46.44","sb":"0.67","za":"354.41","es":"1374.78","lk":"48.24","kn":"0.56","lc":"1","vc":"0.58","sd":"65.93","sr":"3.3","sz":"3.17","se":"444.59","ch":"522.44","sy":"59.63","tw":"426.98","tj":"5.58","tz":"22.43","th":"312.61","tl":"0.62","tg":"3.07","to":"0.3","tt":"21.2","tn":"43.86","tr":"729.05","tm":0,"ug":"17.12","ua":"136.56","ae":"239.65","gb":"2258.57","us":"14624.18","uy":"40.71","uz":"37.72","vu":"0.72","ve":"285.21","vn":"101.99","ye":"30.02","zm":"15.69","zw":"5.57"};
        mapForCountry(countryData);

        //acquisition report table
        //change acquisition data values for timeline
        var acquisitionData = [
            {
                "Source" : "Organic Search",
                "Clicks" : "4",
                "Cost" : "$55.17",
                "CPC" : "$0.28",
                "Users" :"20,674",
                "New Users" :"13,125",
                "Sessions" :"10,254",
                "Bounce Rate" :"39.60%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:01:12",
                "Conversion Rate" :"1.46%",
                "Transactions" :"524",
                "Revenue" :"$5421"
            }, {
                "Source" : "Direct",
                "Clicks" : "2",
                "Cost" : "$72.17",
                "CPC" : "$0.13",
                "Users" :"14,709",
                "New Users" :"7,154",
                "Sessions" :"900",
                "Bounce Rate" :"61.81%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:01:25",
                "Conversion Rate" :"1.07%",
                "Transactions" :"221",
                "Revenue" :"$6589"
            }, {
                "Source" : "Social",
                "Clicks" : "4",
                "Cost" : "$43.17",
                "CPC" : "$0.23",
                "Users" :"13,068",
                "New Users" :"5,214",
                "Sessions" :"500",
                "Bounce Rate" :"64.47%",
                "Pages/Session" :"3.21",
                "Avg Session Duration" :"00:00:25",
                "Conversion Rate" :"0.11%",
                "Transactions" :"325",
                "Revenue" :"$5841"
            }, {
                "Source" : "Referral",
                "Clicks" : "5",
                "Cost" : "$56.17",
                "CPC" : "$0.56",
                "Users" :"4,374",
                "New Users" :"250",
                "Sessions" :"430",
                "Bounce Rate" :"26.11%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:00:60",
                "Conversion Rate" :"6.59%",
                "Transactions" :"251",
                "Revenue" :"$1254"
            }
        ]
        tableForAcquisition(acquisitionData);
    }

    //traffic last six months changes
    function trafficLastSixMonthChanges() {
        
        //top row
        //add data in text()
        $('#totalVisitsTraffic').text('');
        $('#totalVisitTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalSessionsTraffic').text('');
        $('#sessionTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#totalPagesPerSessionsTraffic').text('');
        $('#pagesPerSessionTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalAvgDurationTraffic').text('');
        $('#avgDurationTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //bounceRate
        $('#bounceRate').text('%');

        //user pie chart
        var userData = [55, 40];
        bounceRate('visitor-stats-chart', userData);

        //site specifics
        //add data in text()
        $('#avgPageLoadTime').text();
        $('#avgServerResponseTime').text();
        $('#avgRedirectionTime').text();
        $('#crashes').text();
        $('#exceptions').text();

        //country map
        //change country data for timeline
        var countryData = {"af":"16.63","al":"11.58","dz":"158.97","ao":"85.81","ag":"1.1","ar":"351.02","am":"8.83","au":"1219.72","at":"366.26","az":"52.17","bs":"7.54","bh":"21.73","bd":"105.4","bb":"3.96","by":"52.89","be":"461.33","bz":"1.43","bj":"6.49","bt":"1.4","bo":"19.18","ba":"16.2","bw":"12.5","br":"2023.53","bn":"11.96","bg":"44.84","bf":"8.67","bi":"1.47","kh":"11.36","cm":"21.88","ca":"1563.66","cv":"1.57","cf":"2.11","td":"7.59","cl":"199.18","cn":"5745.13","co":"283.11","km":"0.56","cd":"12.6","cg":"11.88","cr":"35.02","ci":"22.38","hr":"59.92","cy":"22.75","cz":"195.23","dk":"304.56","dj":"1.14","dm":"0.38","do":"50.87","ec":"61.49","eg":"216.83","sv":"21.8","gq":"14.55","er":"2.25","ee":"19.22","et":"30.94","fj":"3.15","fi":"231.98","fr":"2555.44","ga":"12.56","gm":"1.04","ge":"11.23","de":"3305.9","gh":"18.06","gr":"305.01","gd":"0.65","gt":"40.77","gn":"4.34","gw":"0.83","gy":"2.2","ht":"6.5","hn":"15.34","hk":"226.49","hu":"132.28","is":"12.77","in":"1430.02","id":"695.06","ir":"337.9","iq":"84.14","ie":"204.14","il":"201.25","it":"2036.69","jm":"13.74","jp":"5390.9","jo":"27.13","kz":"129.76","ke":"32.42","ki":"0.15","kr":"986.26","undefined":"5.73","kw":"117.32","kg":"4.44","la":"6.34","lv":"23.39","lb":"39.15","ls":"1.8","lr":"0.98","ly":"77.91","lt":"35.73","lu":"52.43","mk":"9.58","mg":"8.33","mw":"5.04","my":"218.95","mv":"1.43","ml":"9.08","mt":"7.8","mr":"3.49","mu":"9.43","mx":"1004.04","md":"5.36","mn":"5.81","me":"3.88","ma":"91.7","mz":"10.21","mm":"35.65","na":"11.45","np":"15.11","nl":"770.31","nz":"138","ni":"6.38","ne":"5.6","ng":"206.66","no":"413.51","om":"53.78","pk":"174.79","pa":"27.2","pg":"8.81","py":"17.17","pe":"153.55","ph":"189.06","pl":"438.88","pt":"223.7","qa":"126.52","ro":"158.39","ru":"1476.91","rw":"5.69","ws":"0.55","st":"0.19","sa":"434.44","sn":"12.66","rs":"38.92","sc":"0.92","sl":"1.9","sg":"217.38","sk":"86.26","si":"46.44","sb":"0.67","za":"354.41","es":"1374.78","lk":"48.24","kn":"0.56","lc":"1","vc":"0.58","sd":"65.93","sr":"3.3","sz":"3.17","se":"444.59","ch":"522.44","sy":"59.63","tw":"426.98","tj":"5.58","tz":"22.43","th":"312.61","tl":"0.62","tg":"3.07","to":"0.3","tt":"21.2","tn":"43.86","tr":"729.05","tm":0,"ug":"17.12","ua":"136.56","ae":"239.65","gb":"2258.57","us":"14624.18","uy":"40.71","uz":"37.72","vu":"0.72","ve":"285.21","vn":"101.99","ye":"30.02","zm":"15.69","zw":"5.57"};
        mapForCountry(countryData);

        //acquisition report table
        //change acquisition data values for timeline
        var acquisitionData = [
            {
                "Source" : "Organic Search",
                "Clicks" : "4",
                "Cost" : "$55.17",
                "CPC" : "$0.28",
                "Users" :"20,674",
                "New Users" :"13,125",
                "Sessions" :"10,254",
                "Bounce Rate" :"39.60%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:01:12",
                "Conversion Rate" :"1.46%",
                "Transactions" :"524",
                "Revenue" :"$5421"
            }, {
                "Source" : "Direct",
                "Clicks" : "2",
                "Cost" : "$72.17",
                "CPC" : "$0.13",
                "Users" :"14,709",
                "New Users" :"7,154",
                "Sessions" :"900",
                "Bounce Rate" :"61.81%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:01:25",
                "Conversion Rate" :"1.07%",
                "Transactions" :"221",
                "Revenue" :"$6589"
            }, {
                "Source" : "Social",
                "Clicks" : "4",
                "Cost" : "$43.17",
                "CPC" : "$0.23",
                "Users" :"13,068",
                "New Users" :"5,214",
                "Sessions" :"500",
                "Bounce Rate" :"64.47%",
                "Pages/Session" :"3.21",
                "Avg Session Duration" :"00:00:25",
                "Conversion Rate" :"0.11%",
                "Transactions" :"325",
                "Revenue" :"$5841"
            }, {
                "Source" : "Referral",
                "Clicks" : "5",
                "Cost" : "$56.17",
                "CPC" : "$0.56",
                "Users" :"4,374",
                "New Users" :"250",
                "Sessions" :"430",
                "Bounce Rate" :"26.11%",
                "Pages/Session" :"1.25",
                "Avg Session Duration" :"00:00:60",
                "Conversion Rate" :"6.59%",
                "Transactions" :"251",
                "Revenue" :"$1254"
            }
        ]
        tableForAcquisition(acquisitionData);
    }

    //traffic year changes
    function trafficYearChanges() {
        
        //top row
        //add data in text()
        $('#totalVisitsTraffic').text('442,650');
        $('#totalVisitTrend').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalSessionsTraffic').text('240,300');
        $('#sessionTrend').text('0.25%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#totalPagesPerSessionsTraffic').text('16');
        $('#pagesPerSessionTrend').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#totalAvgDurationTraffic').text('1:30:30');
        $('#avgDurationTrend').text('0.25%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //bounceRate
        $('#bounceRate').text('32%');

        //user pie chart
        var userData = [55, 40];
        bounceRate('visitor-stats-chart', userData);

        //site specifics
        //add data in text()
        $('#avgPageLoadTime').text('8');
        $('#avgServerResponseTime').text('4.2');
        $('#avgRedirectionTime').text('0.09');
        $('#crashes').text('2');
        $('#exceptions').text('3');

        //country map
        //change country data for timeline
        var countryData = {"af":"16.63","al":"11.58","dz":"158.97","ao":"85.81","ag":"1.1","ar":"351.02","am":"8.83","au":"1219.72","at":"366.26","az":"52.17","bs":"7.54","bh":"21.73","bd":"105.4","bb":"3.96","by":"52.89","be":"461.33","bz":"1.43","bj":"6.49","bt":"1.4","bo":"19.18","ba":"16.2","bw":"12.5","br":"2023.53","bn":"11.96","bg":"44.84","bf":"8.67","bi":"1.47","kh":"11.36","cm":"21.88","ca":"1563.66","cv":"1.57","cf":"2.11","td":"7.59","cl":"199.18","cn":"5745.13","co":"283.11","km":"0.56","cd":"12.6","cg":"11.88","cr":"35.02","ci":"22.38","hr":"59.92","cy":"22.75","cz":"195.23","dk":"304.56","dj":"1.14","dm":"0.38","do":"50.87","ec":"61.49","eg":"216.83","sv":"21.8","gq":"14.55","er":"2.25","ee":"19.22","et":"30.94","fj":"3.15","fi":"231.98","fr":"2555.44","ga":"12.56","gm":"1.04","ge":"11.23","de":"3305.9","gh":"18.06","gr":"305.01","gd":"0.65","gt":"40.77","gn":"4.34","gw":"0.83","gy":"2.2","ht":"6.5","hn":"15.34","hk":"226.49","hu":"132.28","is":"12.77","in":"1430.02","id":"695.06","ir":"337.9","iq":"84.14","ie":"204.14","il":"201.25","it":"2036.69","jm":"13.74","jp":"5390.9","jo":"27.13","kz":"129.76","ke":"32.42","ki":"0.15","kr":"986.26","undefined":"5.73","kw":"117.32","kg":"4.44","la":"6.34","lv":"23.39","lb":"39.15","ls":"1.8","lr":"0.98","ly":"77.91","lt":"35.73","lu":"52.43","mk":"9.58","mg":"8.33","mw":"5.04","my":"218.95","mv":"1.43","ml":"9.08","mt":"7.8","mr":"3.49","mu":"9.43","mx":"1004.04","md":"5.36","mn":"5.81","me":"3.88","ma":"91.7","mz":"10.21","mm":"35.65","na":"11.45","np":"15.11","nl":"770.31","nz":"138","ni":"6.38","ne":"5.6","ng":"206.66","no":"413.51","om":"53.78","pk":"174.79","pa":"27.2","pg":"8.81","py":"17.17","pe":"153.55","ph":"189.06","pl":"438.88","pt":"223.7","qa":"126.52","ro":"158.39","ru":"1476.91","rw":"5.69","ws":"0.55","st":"0.19","sa":"434.44","sn":"12.66","rs":"38.92","sc":"0.92","sl":"1.9","sg":"217.38","sk":"86.26","si":"46.44","sb":"0.67","za":"354.41","es":"1374.78","lk":"48.24","kn":"0.56","lc":"1","vc":"0.58","sd":"65.93","sr":"3.3","sz":"3.17","se":"444.59","ch":"522.44","sy":"59.63","tw":"426.98","tj":"5.58","tz":"22.43","th":"312.61","tl":"0.62","tg":"3.07","to":"0.3","tt":"21.2","tn":"43.86","tr":"729.05","tm":0,"ug":"17.12","ua":"136.56","ae":"239.65","gb":"2258.57","us":"14624.18","uy":"40.71","uz":"37.72","vu":"0.72","ve":"285.21","vn":"101.99","ye":"30.02","zm":"15.69","zw":"5.57"};
        mapForCountry(countryData);

        //acquisition report table
        //change acquisition data values for timeline
        var acquisitionData = [
            {
                "Source" : "Organic Search",
                "Clicks" : "19,612",
                "Cost" : "$7,212 ",
                "CPC" : "$0.37",
                "Users" :"689,932",
                "New Users" :"296,196",
                "Sessions" :"60,644",
                "Bounce Rate" :"30.00%",
                "Pages/Session" :"2",
                "Avg Session Duration" :"00:01:12",
                "Conversion Rate" :"3.00%",
                "Transactions" :"11,576",
                "Revenue" :"$2,22,012 "
            }, {
                "Source" : "Direct",
                "Clicks" : "29,062",
                "Cost" : "$5,712 ",
                "CPC" : "$0.20",
                "Users" :"613,212",
                "New Users" :"216,738",
                "Sessions" :"139,866",
                "Bounce Rate" :"43.00%",
                "Pages/Session" :"1.5",
                "Avg Session Duration" :"01:12:25",
                "Conversion Rate" :"2.00%",
                "Transactions" :"15,588",
                "Revenue" :"$197,212 "
            }, {
                "Source" : "Social",
                "Clicks" : "24,512",
                "Cost" : "$6,312 ",
                "CPC" : "$0.26 ",
                "Users" :"207,492",
                "New Users" :"13,296",
                "Sessions" :"109,836",
                "Bounce Rate" :"23%",
                "Pages/Session" :"2.79",
                "Avg Session Duration" :"00:00:25",
                "Conversion Rate" :"2.20%",
                "Transactions" :"12,756",
                "Revenue" :"$44,212 "
            }, {
                "Source" : "Referral",
                "Clicks" : "12",
                "Cost" : "$12",
                "CPC" : "$1.00",
                "Users" :"12",
                "New Users" :"12",
                "Sessions" :"12",
                "Bounce Rate" :"58.00%",
                "Pages/Session" :"1",
                "Avg Session Duration" :"00:00:25",
                "Conversion Rate" :"3.50%",
                "Transactions" :"12",
                "Revenue" :"$12"
            }
        ]
        tableForAcquisition(acquisitionData);

        var platformData = [
            {						
                "Day/Month/Year"    : "2018 July",
                "Sessions"          : "13290",
                "Users"             : "12129",
                "Page Views"        : "999",
                "Conversion Rate"   : "2%"
            },
            {
                "Day/Month/Year" : "2018 June",
                "Sessions"          : "2186",
                "Users"             : "1814",
                "Page Views"        : "1312",
                "Conversion Rate"   : "0.73%"
            },
            {									
                "Day/Month/Year" : "2018 May",
                "Sessions"          : "5118",
                "Users"             : "3927",
                "Page Views"        : "2000",
                "Conversion Rate"   : "0.86%"
            },
            {			
                "Day/Month/Year" : "2018 Apr",
                "Sessions"          : "4345",
                "Users"             : "3203",
                "Page Views"        : "1001",
                "Conversion Rate"   : "0.20%"
            }
        ]
        tableForPlatform(platformData);
    }
});