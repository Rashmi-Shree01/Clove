$('[data-toggle="popover"]').popover();

$(document).ready(function(){
    
    //adding multiselect options
    $('#addCategory').multiselect();
    $('#addProducts').multiselect();
    //add products table
    function createShoppingDataTable(idToUse, tableData, columns) {
	
        $("#" + idToUse).DataTable(
            {
                destroy : true,
                data : tableData,
                responsive : false,
                paging : false, // false
                lengthChange: false,
                bFilter : false,
                bInfo : false, // false
                scrollX: false,
                language : {
                    emptyTable : "Data not available",
                    "thousands" : ",",
                    "decimals"	: "."
                },
                columns : columns,
                columnDefs: [ {
                    orderable: false,
                    className: 'select-checkbox',
                    targets:   [0]
                } ],
                select: 'multi',
            });
        $('.dataTable').wrap('<div class="dataTables_scroll" />');
    }

    //store products data
    var storeProductsData = [
        {
            "Select"         :   "",
            "ID"             :   "233N",
            "Name"           :   "Fountain Pen",
            "SKU"            :   "23NN45-L",
            "CategoryID"     :   "3455FF",
            "CategoryName"   :   "Student Pens",
            "GTIN"           :   "-",
            "UPC"            :   "-",
            "MPN"            :   "-",
            "Price"          :   "20",
            "Sale Price"     :   "100",
            "Currency"       :   "USD",
            "Discount"       :   "-",
            "Brand"          :   "Parker",
            "Inventory"      :   "18",
            "Availability"   :   "Yes"
        },
        {
            "Select"         :   "",
            "ID"             :   "233N",
            "Name"           :   "Fountain Pen",
            "SKU"            :   "23NN45-L",
            "CategoryID"     :   "3455FF",
            "CategoryName"   :   "Student Pens",
            "GTIN"           :   "-",
            "UPC"            :   "-",
            "MPN"            :   "-",
            "Price"          :   "20",
            "Sale Price"     :   "100",
            "Currency"       :   "USD",
            "Discount"       :   "-",
            "Brand"          :   "Parker",
            "Inventory"      :   "19",
            "Availability"   :   "Yes"
        },
        {
            "Select"         :   "",
            "ID"             :   "233N",
            "Name"           :   "Fountain Pen",
            "SKU"            :   "23NN45-L",
            "CategoryID"     :   "3455FF",
            "CategoryName"   :   "Student Pens",
            "GTIN"           :   "-",
            "UPC"            :   "-",
            "MPN"            :   "-",
            "Price"          :   "20",
            "Sale Price"     :   "100",
            "Currency"       :   "USD",
            "Discount"       :   "-",
            "Brand"          :   "Parker",
            "Inventory"      :   "22",
            "Availability"   :   "Yes"
        }
    ]

    //store products columns
    var storeProductsColumn = [
        {data   :   "Select"},
        {data   :   "ID"},
        {data   :   "Name"},
        {data   :   "SKU"},
        {data   :   "CategoryID"},
        {data   :   "CategoryName"},
        {data   :   "GTIN"},
        {data   :   "UPC"},
        {data   :   "MPN"},
        {data   :   "Price"},
        {data   :   "Sale Price"},
        {data   :   "Currency"},
        {data   :   "Discount"},
        {data   :   "Brand"},
        {data   :   "Inventory"},
        {data   :   "Availability"}
    ]

    //recommended products data
    var recommendedProductsData = [
        {
            "Select"         :   "",
            "ID"             :   "233N",
            "Name"           :   "Fountain Pen",
            "SKU"            :   "23NN45-L",
            "CategoryID"     :   "3455FF",
            "CategoryName"   :   "Student Pens",
            "GTIN"           :   "-",
            "UPC"            :   "-",
            "MPN"            :   "-",
            "Price"          :   "20",
            "Sale Price"     :   "100",
            "Currency"       :   "USD",
            "Discount"       :   "-",
            "Brand"          :   "Parker",
            "Inventory"      :   "18",
            "Availability"   :   "Yes"
        },
        {
            "Select"         :   "",
            "ID"             :   "233N",
            "Name"           :   "Fountain Pen",
            "SKU"            :   "23NN45-L",
            "CategoryID"     :   "3455FF",
            "CategoryName"   :   "Student Pens",
            "GTIN"           :   "-",
            "UPC"            :   "-",
            "MPN"            :   "-",
            "Price"          :   "20",
            "Sale Price"     :   "100",
            "Currency"       :   "USD",
            "Discount"       :   "-",
            "Brand"          :   "Parker",
            "Inventory"      :   "19",
            "Availability"   :   "Yes"
        },
        {
            "Select"         :   "",
            "ID"             :   "233N",
            "Name"           :   "Fountain Pen",
            "SKU"            :   "23NN45-L",
            "CategoryID"     :   "3455FF",
            "CategoryName"   :   "Student Pens",
            "GTIN"           :   "-",
            "UPC"            :   "-",
            "MPN"            :   "-",
            "Price"          :   "20",
            "Sale Price"     :   "100",
            "Currency"       :   "USD",
            "Discount"       :   "-",
            "Brand"          :   "Parker",
            "Inventory"      :   "22",
            "Availability"   :   "Yes"
        }
    ]

    //recommended products column
    var recommendedProductsColumn = [
        {data   :   "Select"},
        {data   :   "ID"},
        {data   :   "Name"},
        {data   :   "SKU"},
        {data   :   "CategoryID"},
        {data   :   "CategoryName"},
        {data   :   "GTIN"},
        {data   :   "UPC"},
        {data   :   "MPN"},
        {data   :   "Price"},
        {data   :   "Sale Price"},
        {data   :   "Currency"},
        {data   :   "Discount"},
        {data   :   "Brand"},
        {data   :   "Inventory"},
        {data   :   "Availability"}
    ]

    createShoppingDataTable('storeProductsTable',storeProductsData,storeProductsColumn);
    createShoppingDataTable('recommendedProductsTable',recommendedProductsData,recommendedProductsColumn);

    //publish products data
    var publishProductsData = [
        {
            "Select": "",
            "ID": "233N",
            "Name": "Fountain Pen",
            "SKU": "23NN45-L",
            "CategoryID": "3455FF",
            "CategoryName": "Student Pens",
            "GTIN": "-",
            "UPC": "-",
            "MPN": "-",
            "Price": "20",
            "Sale Price": "100",
            "Error Description": "Description of the error",
            "Published": "Yes",
            "Edit": "Edit"
        },
        {
            "Select": "",
            "ID": "233N",
            "Name": "Fountain Pen",
            "SKU": "23NN45-L",
            "CategoryID": "3455FF",
            "CategoryName": "Student Pens",
            "GTIN": "-",
            "UPC": "-",
            "MPN": "-",
            "Price": "20",
            "Sale Price": "100",
            "Error Description": "Description of the error",
            "Published": "No",
            "Edit": "Edit"
        },
        {
            "Select": "",
            "ID": "233N",
            "Name": "Fountain Pen",
            "SKU": "23NN45-L",
            "CategoryID": "3455FF",
            "CategoryName": "Student Pens",
            "GTIN": "-",
            "UPC": "-",
            "MPN": "-",
            "Price": "20",
            "Sale Price": "100",
            "Error Description": "Description of the error",
            "Published": "Yes",
            "Edit": "Edit"
        }
    ]

    //publish products columns
    var publishProductsColumn = [
        { data: "Select" },
        { data: "ID" },
        { data: "Name" },
        { data: "SKU" },
        { data: "CategoryID" },
        { data: "CategoryName" },
        { data: "GTIN" },
        { data: "UPC" },
        { data: "MPN" },
        { data: "Price" },
        { data: "Sale Price" },
        { data: "Error Description" },
        { data: "Published",
            render: function(data,type,row){
                if(data.toLowerCase() === "yes"){
                    return "<span class='positive'>"+data+"</span>";
                }else{
                    return "<span class='negative'>"+data+"</span>";
                }
            }
        },
        { data: "Edit",
            render: function(data,type,row){
                return "<a href='#' class='linkColor' data-toggle='modal' data-target='#editModal'>"+data+"</a>"
            } 
        }
    ]

    createShoppingDataTable('publishProductsTable', publishProductsData, publishProductsColumn);

    //center products data
    var centerProductsData = [
        {
            "Select": "",
            "ID": "233N",
            "Name": "Fountain Pen",
            "SKU": "23NN45-L",
            "CategoryID": "3455FF",
            "CategoryName": "Student Pens",
            "GTIN": "-",
            "UPC": "-",
            "MPN": "-",
            "Price": "20",
            "Sale Price": "100",
            "Edit": "Edit"
        },
        {
            "Select": "",
            "ID": "233N",
            "Name": "Fountain Pen",
            "SKU": "23NN45-L",
            "CategoryID": "3455FF",
            "CategoryName": "Student Pens",
            "GTIN": "-",
            "UPC": "-",
            "MPN": "-",
            "Price": "20",
            "Sale Price": "100",
            "Edit": "Edit"
        },
        {
            "Select": "",
            "ID": "233N",
            "Name": "Fountain Pen",
            "SKU": "23NN45-L",
            "CategoryID": "3455FF",
            "CategoryName": "Student Pens",
            "GTIN": "-",
            "UPC": "-",
            "MPN": "-",
            "Price": "20",
            "Sale Price": "100",
            "Edit": "Edit"
        }
    ]

    //center products columns
    var centerProductsColumn = [
        { data: "Select" },
        { data: "ID" },
        { data: "Name" },
        { data: "SKU" },
        { data: "CategoryID" },
        { data: "CategoryName" },
        { data: "GTIN" },
        { data: "UPC" },
        { data: "MPN" },
        { data: "Price"},
        { data: "Sale Price"},
        { data: "Edit",
            render: function(data,type,row){
                return "<a href='#' class='linkColor' data-toggle='modal' data-target='#editCenterModal'>"+data+"</a>"
            }
        }
    ]

    createShoppingDataTable('merchantCenterTable', centerProductsData, centerProductsColumn);
    
    //toggling between store and recommended products table
    $("#recommendedProductBtn").click(function(){
        var buttonClass = $("#recommendedProductBtn").hasClass('btn btn-light');
        byRecommendation = true;
        if(buttonClass) {
            $("#recommendedProductBtn").removeClass('btn btn-light');
            $("#recommendedProductBtn").addClass('btn btn-toggle');
            $("#storeProductBtn").removeClass('btn btn-toggle');
            $("#storeProductBtn").addClass('btn btn-light');
            $(".storeProductsDataTable").hide();
            $(".store-product-title").hide()
            $(".recommended-product-title").show();
            $(".recommendedProductsDataTable").show();
        } 
    });
    
    $("#storeProductBtn").click(function(){
        var buttonClass = $("#storeProductBtn").hasClass('btn btn-light');
        byStore = true;
        if(buttonClass) {
            $("#storeProductBtn").removeClass('btn btn-light');
            $("#storeProductBtn").addClass('btn btn-toggle');
            $("#recommendedProductBtn").removeClass('btn btn-toggle');
            $("#recommendedProductBtn").addClass('btn btn-light');
            $(".recommendedProductsDataTable").hide();
            $(".recommended-product-title").hide();
            $(".store-product-title").show()
            $(".storeProductsDataTable").show();
        } 
    });

    $("#addToFeed").click(function() {
        window.location.replace("shoppingPublish.html");
    });

    tableAlignment();

    if($('.errorText').css('display') !== 'none'){
        $('.inputText').removeClass("col-9");
        $('.inputText').addClass("col-4");
        $('.labelText').removeClass("col-3");
        $('.labelText').addClass("col-2");
    } else {
        $('.inputText').removeClass("col-4");
        $('.inputText').addClass("col-9");
        $('.labelText').removeClass("col-2");
        $('.labelText').addClass("col-3")
    }
});