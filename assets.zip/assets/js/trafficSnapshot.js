$('[data-toggle="popover"]').popover();

var charts = [];

//bounce rate graph
function bounceRate(idToUse, data) {
    $.each(charts, function(index, bar) {
		if (bar['id'] == idToUse) {
			bar['object'].destroy();
		}
    })
    var parent = $("#" + idToUse).parent();
	$(parent).html("");
	$(parent).append("<canvas id='" + idToUse + "' />");
    var ctx = $("#"+idToUse);
    var chart = new Chart(ctx, {
        type: 'pie',
        responsive: true,
        maintainAspectRatio: true,
        data: {
            labels: ['New User', 'Returning User' ],
            datasets: [{
                label: "Dataset",
                data: data,
                //fill: false,
                backgroundColor:[
                                    "rgb(144,135,192)",
                                    "rgb(150,209,243)"
                ],
                borderWidth:2
            }]
        },
        options: {
            animateRotate: true,
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    boxWidth: 10
                }
            }
        }
    });
    var index = -1;
	$.each(charts, function(i, bar) {
		if (bar['id'] == idToUse) {
			index = i;
		}
	})
	if (index != -1) {
		charts.splice(index, 1);
	}
	var bar = {
		id : idToUse,
		object : chart
	}
	charts.push(bar);
}

// country specific map and table
function tableForCountry(requiredData) {

    $("#countryTable").DataTable({
        order : [],
        data : requiredData,
        paging : true,
        bFilter: false,
        sDom: "<'row'<'col-sm-12'tr>>" +
                 "<'row'<'col-sm-4'i><'col-sm-8'p>>" ,
        language : {
            emptyTable : "Data not available"
        },
        columns : [ 
                    { data : 'Customers Live Here',
                      render: function(data, type, row, meta) {
                            data = '<p class="flag-icon flag-icon-"'+countryCode+'></p> ' + data;
                            return data;  
                        }
                    }, 
                    { data : 'Visitors' }, 
                    { data : 'Revenue' }, 
        ]
    });
    $('.dataTable').wrap('<div class="dataTables_scroll" />');
}

//map for country
function mapForCountry(data) {

    var max = 0,
    min = Number.MAX_VALUE,
    cc,
    startColor = [200, 238, 255],
    endColor = [0, 100, 145],
    colors = {},
    hex;

    //find maximum and minimum values
    for (cc in data)
    {
        if (parseFloat(data[cc]) > max)
        {
            max = parseFloat(data[cc]);
        }
        if (parseFloat(data[cc]) < min)
        {
            min = parseFloat(data[cc]);
        }
    }

    //set colors according to values of GDP
    for (cc in data)
    {
        if (data[cc] > 0)
        {
            colors[cc] = '#';
            for (var i = 0; i<3; i++)
            {
                hex = Math.round(startColor[i]
                    + (endColor[i]
                    - startColor[i])
                    * (data[cc] / (max - min))).toString(16);

                if (hex.length == 1)
                {
                    hex = '0'+hex;
                }

                colors[cc] += (hex.length == 1 ? '0' : '') + hex;
            }
        }
    }

    $('#vmap').vectorMap({
        enableZoom: true,
        colors: colors,
        hoverOpacity: 0.7,
        hoverColor: false,
        backgroundColor : 'transparent',
        showTooltip: true,
        onLabelShow : function(event, label, code) {
            var val = data[code] == undefined ? 0 : data[code];
            label.append(' : (Visits - ' + val + ')');
        }
    });
}

//table for acquisiton report
function tableForAcquisition(data) {      
    var keyTable = $("#acquisitionTable").DataTable({
        order : [],
        data : data,
        scrollX: true,
        paging : true,
        destroy : true,
        info : true,
        sDom: "<'row'<'col-sm-12'tr>>" +
         "<'row'<'col-sm-4'i><'col-sm-8'p>>",
        language : {
            emptyTable : "Data not available"
        },
        columns : [ {data : 'Source'}, 
                    {data : 'Clicks'},
                    {data : 'Cost'}, 
                    {data : 'CPC'},
                    {data : 'Users'},
                    {data : 'New Users'},
                    {data : 'Sessions'}, 
                    {data : 'Bounce Rate'}, 
                    {data : 'Pages/Session'}, 
                    {data : 'Avg Session Duration'},
                    {data : 'Conversion Rate'}, 
                    {data : 'Transactions'},
                    {data : 'Revenue'} 
        ],
        columnDefs : [
                        {width: "10%", targets: 0}
        ]
    });
    $('.dataTable').wrap('<div class="dataTables_scroll" />'); 
}

//table for platform data
function tableForPlatform(data) {      
    var keyTable = $("#platformDataView").DataTable({
        order : [],
        data : data,
        scrollX: true,
        paging : true,
        destroy : true,
        info : true,
        sDom: "<'row'<'col-sm-12'tr>>" +
         "<'row'<'col-sm-4'i><'col-sm-8'p>>",
        language : {
            emptyTable : "Data not available"
        },
        columns : [ {data : 'Day/Month/Year'}, 
                    {data : 'Sessions'},
                    {data : 'Users'}, 
                    {data : 'Page Views'},
                    {data : 'Conversion Rate'}
        ],
        columnDefs : [
                        {width: "10%", targets: 0}
        ]
    });
    $('.dataTable').wrap('<div class="dataTables_scroll" />'); 
}
//for showing different mobile options and tablet options
$("#mobileOptions").click(function() {
    if($("#mobileOptions").text() == "+") {
        $("#mobileOptions").html("-");
        $("#iosOption").show();
        $("#androidOption").show();
        $('.filter-radio').prop('checked', false);
    } else {
        $("#mobileOptions").html("+");
        $("#iosOption").hide();
        $("#androidOption").hide();
        $('.filter-radio').prop('checked', false);
    }
});

$("#tabOptions").click(function() {
    if($("#tabOptions").text() == "+") {
        $("#tabOptions").html("-");
        $("#iosTabOption").show();
        $("#androidTabOption").show();
        $('.filter-radio').prop('checked', false);
    } else {
        $("#tabOptions").html("+");
        $("#iosTabOption").hide();
        $("#androidTabOption").hide();
        $('.filter-radio').prop('checked', false);
    }
});

$('input[type="radio"]').click(function() {
    var checkedValue = $(this).val();
    if(checkedValue == "iosOpt" || checkedValue == "androidOpt") {
        $('#allOpt').prop('checked', false);
        $('#desktopOpt').prop('checked', false);
        $('#mobileOpt').prop('checked', false);
        $("#iosTabOption").hide();
        $("#androidTabOption").hide();
        $("#tabOptions").html("+");
        $('#tabOpt').prop('checked', false);
    } else if((checkedValue == "allOpt") || (checkedValue == "mobileOpt") || (checkedValue == "desktopOpt")) {
        $('.filter-radio').prop('checked', false);
        $("#iosOption").hide();
        $("#androidOption").hide();
        $("#mobileOptions").html("+");
        $("#iosTabOption").hide();
        $("#androidTabOption").hide();
        $("#tabOptions").html("+");
    } else if(checkedValue == "iosTabOpt" || checkedValue == "androidTabOpt") {
        $('#allOpt').prop('checked', false);
        $('#desktopOpt').prop('checked', false);
        $('#mobileOpt').prop('checked', false);
        $("#iosOption").hide();
        $("#androidOption").hide();
        $("#mobileOptions").html("+");
        $('#tabOpt').prop('checked', false);
    }
});

$("#countrySpecificTable").click( function() {
    var buttonClass = $("#countrySpecificTable").hasClass('btn btn-light');
    if(buttonClass) {
        $("#countrySpecificTable").removeClass('btn btn-light');
        $("#countrySpecificTable").addClass('btn btn-toggle');
        $("#worldMap").removeClass('btn btn-toggle');
        $("#worldMap").addClass('btn btn-light');
        $('.country-map-container').hide();
        $('.countryCustomers').show();
    } 
});

$("#worldMap").click( function() {
    var buttonClass = $("#worldMap").hasClass('btn btn-light');
    if(buttonClass) {
        $("#worldMap").removeClass('btn btn-light');
        $("#worldMap").addClass('btn btn-toggle');
        $("#countrySpecificTable").removeClass('btn btn-toggle');
        $("#countrySpecificTable").addClass('btn btn-light');
        $('.countryCustomers').hide();
        $('.country-map-container').show();
    } 
});

$(document).ready( function () {
    
    

    var countryTableData = [ 
        {
            "Customers Live Here" : "United States",
            "Visitors" : "1694",
            "Revenue" : "$0.00" 
        },
        {
            "Customers Live Here" : "India",
            "Visitors" : "634",
            "Revenue" : "$399"
        },
        {
            "Customers Live Here" : "United Kingdom",
            "Visitors" : "503",
            "Revenue" : "$51.4"
        },
        {
            "Customers Live Here" : "Germany",
            "Visitors" : "290",
            "Revenue" : "$49.99"
        }, 
        {
            "Customers Live Here" : "Canada",
            "Visitors" : "271",
            "Revenue" : "$49.99"
        } ,
        {
            "Customers Live Here" : "Australia",
            "Visitors" : "123",
            "Revenue" : "$2.98"
        } 
    ]
    //tableForCountry(countryTableData);
    
    //table for campaign stats
    /*var data = [
            {
                "Campaign"          :   "celebrity-testimonial-shirts",
                "Channel"           :   "eBay",
                "Keywords"          :   "google merch",
                "Impressions"       :   "94,238,077",
                "Clicks"            :   "4,91,315",
                "Spend"             :   "$2,46,871",
                "New Customers"     :   "645",
                "CPC"               :   "$382",
                "1st Order Revenue" :   "$55",
                "ROI-1st Order"     :   "-85.62%"
            },
            {
                "Campaign"          :   "female-style-retargeting",
                "Channel"           :   "Amazon",
                "Keywords"          :   "google merch+",
                "Impressions"       :   "936,382,603",
                "Clicks"            :   "5,34,371",
                "Spend"             :   "$1,71,630",
                "New Customers"     :   "644",
                "CPC"               :   "$266",
                "1st Order Revenue" :   "$52",
                "LTV"               :   "$58",
                "ROI-1st Order"     :   "-80.62%"
            },
            {
                "Campaign"          :   "female-value-retargeting",
                "Channel"           :   "Flipkart",
                "Keywords"          :   "google+",
                "Impressions"       :   "702,304,766",
                "Clicks"            :   "4,08,778",
                "Spend"             :   "$1,30,745",
                "New Customers"     :   "636",
                "CPC"               :   "$205",
                "1st Order Revenue" :   "$51",
                "ROI-1st Order"     :   "-74.81%"
            },
            {
                "Campaign"          :   "male-style-retargeting",
                "Channel"           :   "Amazon",
                "Keywords"          :   "google+merch",
                "Impressions"       :   "702,663,301",
                "Clicks"            :   "2,68,661",
                "Spend"             :   "$85,105",
                "New Customers"     :   "638",
                "CPC"               :   "$133",
                "1st Order Revenue" :   "$52",
                "ROI-1st Order"     :   "-60.51%"
            }
    ]
    function tableForCampaignStats() {
        var keyTable = $("#campaignStats").DataTable({
            order : [],
            data : data,
            paging : true,
            info : true,
            sDom: "<'row'<'col-sm-12'tr>>" +
             "<'row'<'col-sm-4'i><'col-sm-8'p>>",
            language : {
                emptyTable : "Data not available"
            },
            columns : [ {data : 'Campaign'}, 
                        {data : 'Channel'},
                        {data : 'Keywords'},
                        {data : 'Impressions'},
                        {data : 'Clicks'}, 
                        {data : 'Spend'},
                        {data : 'New Customers'},
                        {data : 'CPC'}, 
                        {data : '1st Order Revenue'}, 
                        {data : 'ROI-1st Order'} 
                    ],
            columnDefs : [ {
                                "targets" : 1,
                                "visible" : false,
                            }, 
                            {
                                "targets" : 2,
                                "visible" : false
                            } 
            ]
        });
        $('.dataTable').wrap('<div class="dataTables_scroll" />');
        $("#campaignStatSelect").change( function() {
            var selectedTime = $("#campaignStatSelect option:selected").val();
            if (selectedTime == "Channel") {
                keyTable.column(1).visible(true);
                $("#hideCampaignChannel").show();
            } else if (selectedTime == "Keywords") {
                keyTable.column(2).visible(true);
                $("#hideCampaignKeyword").show();
            } else {
                keyTable.column(1).visible(false);
                keyTable.column(2).visible(false);
                $("#hideCampaignChannel").hide();
                $("#hideCampaignKeyword").hide();
            }

        });

        $("#hideCampaignChannel").click(function() {
            keyTable.column(1).visible(false);
            $("#hideCampaignChannel").hide();
            $('#campaignStatSelect').prop('selectedIndex',0);
        });

        $("#hideCampaignKeyword").click(function() {
            keyTable.column(2).visible(false);
            $("#hideCampaignKeyword").hide();
            $('#campaignStatSelect').prop('selectedIndex',0);
        });
    }*/
    
    //change targeting chart
    /*function lossTargeting() {
        var ctx = $("#lossTargetsChart");
	    var acquisitionDataChart = new Chart( ctx, {
            type: 'horizontalBar',
            data: {
                labels: [ "female-style-retargeting", "female-value-retargeting", "NA-seasonal", "SA-seasonal"],
                datasets: [ {
                    data: [-80.45, -74.81, -90, -84],
                    borderColor: "rgb(144,135,192)",
                    borderWidth: "0",
                    backgroundColor: "rgb(144,135,192)"
                } ],
            },
            options: {
                legend: {
                    display: false,
                },
                scales : {
                    xAxes : [ {
                        ticks : {
                            stepSize : 20,
                            beginAtZero : true
                        }
                    } ]
                },
                responsive : false
            }
	    });
    }

    //invest campaign chart
    function profitTargeting() {
        var ctx = $("#profitTargetsChart");
	    var acquisitionDataChart = new Chart( ctx, {
            type: 'horizontalBar',
            maintainAspectRatio: false,
            data: {
                labels: [ "celebrity-testimonial-shirts", "male-style-retargeting", "male-value-retargeting", "socks-evergreen"],
                datasets: [ {
                    data: [85.62, 110, 70, 78],
                    borderColor: "rgb(150,209,243)",
                    borderWidth: "0",
                    backgroundColor:  "rgb(150,209,243)"
                } ],
            },
            options: {
                legend: {
                    display: false,
                },
                scales : {
                    xAxes : [ {
                        ticks : {
                            stepSize : 20,
                            beginAtZero : true
                        }
                    } ]
                },
                responsive : false
            }
	    });
    }*/

});