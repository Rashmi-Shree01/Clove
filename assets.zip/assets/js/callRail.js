$(document).ready( function() {

    var callsDataset = {
        label: "No. of Calls",
        data: [ 400, 300, 150, 600 ],
        backgroundColor: "rgb(144,135,192)",
        hoverBackgroundColor:"rgb(144,135,192)"
    }

    var leadsDataset = {
        label: "No. of Leads",
        data: [ 250, 200, 100, 300 ],
        backgroundColor: "rgb(150,209,243)",
        hoverBackgroundColor: "rgb(150,209,243)"
    }

    function callsAndLeads() {
        var ctx = $('#callsBarChart');
        var chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["Direct", "Google Paid", "Google Organic", "Others"],
            datasets: [ callsDataset, leadsDataset ]
            },
            options: {
                legend: {
                    display: true,
                    labels: {
                        boxWidth: 10
                    }
                },
                scales : {
                    xAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString: 'Source'
                        },
                        ticks : {
                            stepSize : 1,
                            min : 0,
                            autoSkip : false
                        }
                    } ],
                    yAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString : ''
                        }, 
                        ticks : {
                            beginAtZero: true
                        }
                    } ]
                },
                responsive : true,
                title : {
                    display : false
                }
            }
        });
    }
    callsAndLeads();

    function callsTrend() {
        var ctx = $("#callsTrendChart");
	    var acquisitionDataChart = new Chart( ctx, {
            type: 'line',
            data: {
                labels: [ "29-04-2018", "30-04-2018", "01-05-2018", "02-05-2018", "03-05-2018", "04-05-2018", "05-05-2018" ],
                datasets: [{
                    label: "No. of Calls",
                    fill: false,
                    data: [ 100, 300, 150, 200, 300, 350, 333, 500, 600],
                    borderColor: "rgb(144,135,192)",
                    tension: 0,
                    backgroundColor : 'transparent'
                }]
            },
            options: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        boxWidth: 10,
                    }
                },
                scales : {
                    xAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString: 'Date'
                        },
                        ticks : {
                            stepSize : 1,
                            min : 0,
                            autoSkip : false
                        }
                    } ],
                    yAxes : [ {
                        scaleLabel : {
                            display : true,
                            labelString : 'No. of Calls'
                        },
                        ticks : {
                            beginAtZero : true
                        }
                    } ]
                },
                responsive : true,
                stacked : true,
                title : {
                    display : false
                }
            }
	    });
    }

    //toggling between bar chart and trend
    $("#currentTrendChart").click(function(){
        var buttonClass = $("#currentTrendChart").hasClass('btn btn-light');
        if(buttonClass) {
            $("#currentTrendChart").removeClass('btn btn-light');
            $("#currentTrendChart").addClass('btn btn-toggle');
            $("#currentBarChart").removeClass('btn btn-toggle');
            $("#currentBarChart").addClass('btn btn-light');
            $(".callsBar").hide();
            $(".callsTrend").show();
            callsTrend();
        } 
    });

    $("#currentBarChart").click(function(){
        var buttonClass = $("#currentBarChart").hasClass('btn btn-light');
        if(buttonClass) {
            $("#currentBarChart").removeClass('btn btn-light');
            $("#currentBarChart").addClass('btn btn-toggle');
            $("#currentTrendChart").removeClass('btn btn-toggle');
            $("#currentTrendChart").addClass('btn btn-light');  
            $(".callsTrend").hide();
            $(".callsBar").show();
            callsAndLeads();
        } 
    });

    // calls pie chart 
    var forPie = $('#callsPieChart');
	var callsChart = new Chart(forPie, {
            type: 'pie',
            responsive: true,
            maintainAspectRatio: false,
            data: {
                labels: ['Google Paid', 'Organic', 'Direct'],
                datasets: [{
                    label: "Dataset",
                    data: [25, 17, 5],
                    backgroundColor:[
                                        "rgb(144,135,192)",
                                        "rgb(150,209,243)",
                                        "rgb(244,137,167)",
                    ],
                    borderColor:[
                                        "rgb(144,135,192)",
                                        "rgb(150,209,243)",
                                        "rgb(244,137,167)",
                    ],
                    borderWidth:2
                }]
            },
            options: {
                animateRotate: true,
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        boxWidth: 10
                    }
                }
        }
    });

    //table alignment
    $('td').filter(function() {
        return this.innerHTML.match(/^[0-9\%\$\s\.,]+$/);
      }).css('text-align','right');
}); 