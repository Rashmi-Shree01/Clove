$('body').toggleClass('open');

function tableAlignment() {
	//table alignment
	$('td').filter(function() {
		return this.innerHTML.match(/^[-\0-9\%\$\:\s\.,]+$/);
	}).css('text-align','right');
}
$(document).ready(function($) {

	"use strict";
	$('#filterNav').click(function(){
		document.getElementById("mySidenav").style.width = "186px";
	});
	$('.closebtn').click(function(){
		document.getElementById("mySidenav").style.width = "0";
	});

	// var acc = document.getElementsByClassName("accordion");
	// var i;

	// for (i = 0; i < acc.length; i++) {
	// 	acc[i].addEventListener("click", function() {
	// 		/* Toggle between adding and removing the "active" class,
	// 		to highlight the button that controls the panel */
	// 		this.classList.toggle("active");

	// 		/* Toggle between hiding and showing the active panel */
	// 		var panel = this.nextElementSibling;
	// 		if (panel.style.display === "block") {
	// 			panel.style.display = "none";
	// 		} else {
	// 			panel.style.display = "block";
	// 		}
	// 	});
	// }

	if($(window).width()<551) {
		$('body').toggleClass('open');
	} 

	$('[data-toggle="tooltip"]').tooltip({
        trigger : 'hover'
	});

	$('#menuToggle').on('click', function(event) {
		$('body').toggleClass('open');
	});

	$('td').filter(function() {
        return this.innerHTML.match(/^[0-9\%\$\s\.,]+$/);
      }).css('text-align','right');

	// $('.search-trigger').on('click', function(event) {
	// 	event.preventDefault();
	// 	event.stopPropagation();
	// 	$('.search-trigger').parent('.header-left').addClass('open');
	// });

	// $('.search-close').on('click', function(event) {
	// 	event.preventDefault();
	// 	event.stopPropagation();
	// 	$('.search-trigger').parent('.header-left').removeClass('open');
	// });

	// $('.user-area> a').on('click', function(event) {
	// 	event.preventDefault();
	// 	event.stopPropagation();
	// 	$('.user-menu').parent().removeClass('open');
	// 	$('.user-menu').parent().toggleClass('open');
	// });


});
